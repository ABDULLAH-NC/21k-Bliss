const applyBlueHeaderStyle = (header) => {
    header.style.background = 'linear-gradient(135deg, #1e90ff, #4169e1)'; // blue tones
    header.style.color = '#ffffff'; // white text for contrast
    header.style.boxShadow = '0 0 10px #4682b4'; // soft blue glow
    header.style.transition = 'all 0.3s ease';
  };
  
  // Check if header already exists
  const existingHeader = document.querySelector('header');
  if (existingHeader) {
    applyBlueHeaderStyle(existingHeader);
  } else {
    // Wait for it if not there
    const observer = new MutationObserver((mutations, obs) => {
      const header = document.querySelector('header');
      if (header) {
        applyBlueHeaderStyle(header);
        obs.disconnect();
      }
    });
  
    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }
  
  // Base Background
  document.body.style.background = '#e6f2ff';
  document.body.style.color = '#003366';
  
  // Universal Link Styling
  const blueStyle = document.createElement('style');
  blueStyle.innerHTML = `
    a {
      color: #0066cc !important;
      text-shadow: 0 0 4px #b3d9ff, 0 0 8px #99ccff;
      transition: 0.3s;
    }
    a:hover {
      color: #004080 !important;
    }
    h1, h2, h3, h4, h5, h6 {
      color: #0052a3 !important;
      text-shadow: 0 0 6px #b3d9ff, 0 0 12px #99ccff;
    }
    p {
      color: #003366 !important;
    }
    button, .Button {
      background: linear-gradient(90deg, #4da6ff, #80bfff);
      color: white;
      padding: 8px 16px;
      border: none;
      border-radius: 2rem;
      box-shadow: 0 0 10px #66b3ff;
      cursor: pointer;
      font-weight: bold;
      transition: 0.3s;
    }
    button:hover, .Button:hover {
      box-shadow: 0 0 20px #99ccff;
    }
  
    @keyframes blueGradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    ._active-gradient-animated {
      background: linear-gradient(270deg, #4da6ff, #e6f2ff);
      background-size: 400% 400%;
      animation: blueGradientShift 5s ease infinite;
      color: #003366 !important;
      border-radius: 1rem !important;
    }
  
    @keyframes blueGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    @keyframes thinShineSweep {
      0% { left: -50%; top: -50%; }
      100% { left: 150%; top: 150%; }
    }
  
    .blue-shiny {
      background: linear-gradient(270deg, #4da6ff, #e6f2ff, #4da6ff);
      background-size: 400% 400%;
      animation: blueGradientMove 6s ease-in-out infinite;
      color: #003366 !important;
      border-radius: 1rem !important;
      position: relative;
      overflow: hidden;
      z-index: 0;
    }
  
    .blue-shiny::after {
      content: '';
      position: absolute;
      width: 150%;
      height: 2px;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
      animation: thinShineSweep 2.5s linear infinite;
      transform: rotate(45deg);
      pointer-events: none;
      z-index: 1;
    }
  
    .rounded-icon {
      background: linear-gradient(135deg, #e6f2ff, #cce6ff);
      border-radius: 50%;
      padding: 10px;
      color: #0066cc;
      text-shadow: 0 0 6px #b3d9ff;
      transition: 0.3s;
    }
  
    .rounded-icon:hover {
      color: #004080;
      text-shadow: 0 0 10px #99ccff;
    }
  
    .animated-bar {
      background: linear-gradient(270deg, #4da6ff, #cce6ff);
      background-size: 300% 300%;
      animation: blueGradientShift 6s ease-in-out infinite;
    }
  
    .Icon-arrow_up {
      background: linear-gradient(135deg, #e6f2ff, #cce6ff);
      border-radius: 50%;
      padding: 10px;
      color: #0066cc;
      text-shadow: 0 0 6px #b3d9ff;
      transition: 0.3s;
    }
  
    .Icon-arrow_up:hover {
      color: #004080;
      text-shadow: 0 0 10px #99ccff;
    }
  `;
  document.head.appendChild(blueStyle);
  
  // Animated glowing gradient text for _main ._label
  (function () {
    const el = document.querySelector('._main ._label');
    if (!el) return;
  
    el.style.backgroundImage = 'linear-gradient(90deg, white, #4da6ff, white)';
    el.style.backgroundSize = '300% auto';
    el.style.color = 'transparent';
    el.style.backgroundClip = 'text';
    el.style.webkitBackgroundClip = 'text';
    el.style.fontWeight = 'bold';
    el.style.animation = 'shine 2s linear infinite, glow 1.5s ease-in-out infinite alternate';
    el.style.textShadow = `
      0 0 4px #66b3ff,
      0 0 8px #4da6ff,
      0 0 16px #1a8cff,
      0 0 24px white
    `;
  })();
  
  // Apply to common components
  const blueSelectors = [
    '._top', '._bottom',
    '.main-v2f8c4', '.main-zf0xiu', '.main-1tz8zqw',
    '.main-hp9qcx', '.main-x9v4u5', '.in_container',
    '._clickable', '.Icon-arrow_up', '.fa-play'
  ];
  
  function applyBlueTheme(el) {
    if (el.classList.contains('_top') || el.classList.contains('_bottom')) {
      el.classList.add('animated-bar');
      el.style.color = '#003366';
      el.querySelectorAll('*').forEach(child => {
        child.style.color = '#003366';
        child.style.textShadow = '0 0 6px #66b3ff';
      });
      return;
    }
  
    el.style.background = 'linear-gradient(135deg, #e6f2ff, #cce6ff)';
    el.style.color = '#003366';
    el.style.borderRadius = '1rem';
    el.style.textShadow = '0 0 6px #b3d9ff';
  
    if (el.classList.contains('Icon-arrow_up') || el.classList.contains('fa-play')) {
      el.classList.add('rounded-icon');
    }
  
    el.querySelectorAll('*').forEach(child => {
      child.style.color = '#003366';
      child.style.textShadow = '0 0 6px #b3d9ff';
    });
  }
  
  document.querySelectorAll(blueSelectors.join(',')).forEach(applyBlueTheme);
  
  const blueObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (blueSelectors.some(sel => node.matches(sel))) {
            applyBlueTheme(node);
          }
          node.querySelectorAll(blueSelectors.join(',')).forEach(applyBlueTheme);
        }
      }
    }
  });
  blueObserver.observe(document.body, { childList: true, subtree: true });
  
  // _active animation
  const blueStyledElements = new WeakMap();
  setInterval(() => {
    document.querySelectorAll('._active').forEach(el => {
      if (!el.classList.contains('_active-gradient-animated')) {
        if (!blueStyledElements.has(el)) {
          blueStyledElements.set(el, {
            background: el.style.background,
            color: el.style.color,
            borderRadius: el.style.borderRadius,
          });
        }
        el.classList.add('_active-gradient-animated');
      }
    });
  }, 300);
  
// 🔵 Hero Shine Effect – Blue Theme
function applyBlueShiny(el) {
  if (!el.classList.contains('blue-shiny')) {
    el.classList.add('blue-shiny');
  }
}

const blueTarget = document.querySelector('.main-y3ei6l');
if (blueTarget) applyBlueShiny(blueTarget);

const blueWatcher = new MutationObserver(() => {
  const el = document.querySelector('.main-y3ei6l');
  if (el) {
    applyBlueShiny(el);
    blueWatcher.disconnect();
  }
});
blueWatcher.observe(document.body, { childList: true, subtree: true });


  
  // _today styling
  function styleTodayElement(el) {
    el.style.background = 'linear-gradient(135deg, #66b3ff, #3399ff)';
    el.style.color = '#003366';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #66b3ff';
    el.style.fontWeight = 'bold';
  }
  document.querySelectorAll('._today').forEach(styleTodayElement);
  const observerToday = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_today')) {
            styleTodayElement(node);
          }
          node.querySelectorAll('._today').forEach(styleTodayElement);
        }
      }
    }
  });
  observerToday.observe(document.body, { childList: true, subtree: true });
  
  // Apply to existing elements
  document.querySelectorAll('._fore').forEach(styleForeElement);
  
  // Observe and style new elements dynamically
  const observerFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_fore')) styleForeElement(node);
          node.querySelectorAll('._fore').forEach(styleForeElement);
        }
      }
    }
  });
  observerFore.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 BLUE STYLING FOR _day AND _note
  function styleBlueDay(el) {
    el.style.background = 'linear-gradient(135deg, #99ccff, #4da6ff)';
    el.style.color = '#003366';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #66b3ff';
    el.style.fontWeight = 'bold';
  }
  function styleBlueNote(el) {
    el.style.background = 'linear-gradient(135deg, #e6f2ff, #b3d9ff)';
    el.style.color = '#003366';
    el.style.borderRadius = '0.75rem';
    el.style.padding = '8px';
    el.style.boxShadow = '0 0 10px #99ccff';
  }
  document.querySelectorAll('._day').forEach(styleBlueDay);
  document.querySelectorAll('._note').forEach(styleBlueNote);
  const observerBlue = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('_day')) styleBlueDay(node);
        if (node.classList.contains('_note')) styleBlueNote(node);
        node.querySelectorAll('._day').forEach(styleBlueDay);
        node.querySelectorAll('._note').forEach(styleBlueNote);
      }
    }
  });
  observerBlue.observe(document.body, { childList: true, subtree: true });
  
  // Blue calendar icon
  function styleBlueCalendar(el) {
    el.style.color = '#0066cc';
    el.style.textShadow = '0 0 6px #b3d9ff';
    el.style.background = 'none';
  }
  document.querySelectorAll('.fa-calendar-alt').forEach(styleBlueCalendar);
  const calendarObserverBlue = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('fa-calendar-alt')) {
          styleBlueCalendar(node);
        }
        node.querySelectorAll('.fa-calendar-alt').forEach(styleBlueCalendar);
      }
    }
  });
  calendarObserverBlue.observe(document.body, { childList: true, subtree: true });
  
  // Blue style for .fa-calendar-star
  const style = document.createElement('style');
  style.textContent = `
    .fa-calendar-star,
    .fa-calendar-star::before {
      color: #3399ff !important;
    }
  `;
  document.head.appendChild(style);
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.classList?.contains('fa-calendar-star')) {
            node.style.color = '#3399ff';
          } else {
            node.querySelectorAll?.('.fa-calendar-star')?.forEach(el => {
              el.style.color = '#3399ff';
            });
          }
        }
      });
    });
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // 🟡 Only change text color of _dots elements to blue
  function styleBlueDots(el) {
    el.style.color = '#0066cc';
    el.style.textShadow = '0 0 4px #b3d9ff';
  }
  
  // Apply to existing ._dots elements
  document.querySelectorAll('._dots').forEach(styleBlueDots);
  
  // Observe for future ._dots elements
  const observerDots = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('_dots')) styleBlueDots(node);
        node.querySelectorAll('._dots').forEach(styleBlueDots);
      }
    }
  });
  observerDots.observe(document.body, { childList: true, subtree: true });
  
  // 7/15/2025
  document.querySelectorAll('._fore').forEach(el => {
    el.style.setProperty('background', 'linear-gradient(135deg, #4da6ff, #1a8cff)', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #4da6ff', 'important');
  
    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  });
  
  // 🟡 Combined Blue Theme Enhancements
  
  // 🟡 Font Awesome Icons to Blue
  function styleAllFontAwesome(el) {
    el.style.setProperty('color', '#0066cc', 'important');
    el.style.setProperty('textShadow', '0 0 6px #b3d9ff', 'important');
  }
  document.querySelectorAll('.fa, .fas, .far, .fal, .fab').forEach(styleAllFontAwesome);
  const observerFA = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.toString().match(/\bfa[bsrl]?\b/)) {
          styleAllFontAwesome(node);
        }
        node.querySelectorAll?.('.fa, .fas, .far, .fal, .fab')?.forEach(styleAllFontAwesome);
      }
    }
  });
  observerFA.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Blue Background for .main-1k6w26b
  const styleMain = document.createElement('style');
  styleMain.innerHTML = `
    .main-1k6w26b {
      background: linear-gradient(135deg, #e6f2ff, #cce6ff) !important;
      color: #0066cc !important;
      border: 2px solid #99ccff !important;
      border-radius: 0.75rem !important;
      box-shadow: 0 0 10px #99ccff !important;
      padding: 12px !important;
      transition: border 0.3s ease, box-shadow 0.3s ease;
    }
    .main-1k6w26b:hover {
      border: 2px solid #0066cc !important;
      box-shadow: 0 0 14px #0066cc !important;
    }
  `;
  document.head.appendChild(styleMain);
  function styleBlueMainBlock(el) {
    el.classList.add('main-1k6w26b');
  }
  document.querySelectorAll('.main-1k6w26b').forEach(styleBlueMainBlock);
  const observerBlueMainBlock = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('main-1k6w26b')) {
          styleBlueMainBlock(node);
        }
        node.querySelectorAll?.('.main-1k6w26b')?.forEach(styleBlueMainBlock);
      }
    }
  });
  observerBlueMainBlock.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Blue Border Shades for .main-uv8k3y
  const styleUv = document.createElement('style');
  styleUv.innerHTML = `
    .main-uv8k3y {
      border: 2px solid #66b3ff !important;
      transition: border 0.3s ease, box-shadow 0.3s ease;
      border-radius: 0.75rem !important;
    }
    .main-uv8k3y:hover {
      border: 2px solid #0066cc !important;
      box-shadow: 0 0 10px #0066cc !important;
    }
  `;
  document.head.appendChild(styleUv);
  
  // Apply to existing elements
  document.querySelectorAll('.main-uv8k3y').forEach(el => {
    el.classList.add('main-uv8k3y');
  });
  
  // Observe and apply to new elements
  const observerUv = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList?.contains('main-uv8k3y')) {
          node.classList.add('main-uv8k3y');
        }
  
        node.querySelectorAll?.('.main-uv8k3y')?.forEach(el => {
          el.classList.add('main-uv8k3y');
        });
      }
    }
  });
  observerUv.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Make all elements inside ._fore have transparent background
  function applyForeInnerStyle(el) {
    const darkBlue = '#cce6ff';
  
    el.querySelectorAll('*').forEach(child => {
      const isFontAwesome =
        [...child.classList].some(cls =>
          cls.startsWith('fa') || ['fas', 'far', 'fal', 'fab'].includes(cls)
        );
  
      if (isFontAwesome) {
        child.style.setProperty('background', darkBlue, 'important');
        child.style.setProperty('color', '#0066cc', 'important');
        child.style.setProperty('borderRadius', '0.5rem', 'important');
        child.style.setProperty('padding', '6px', 'important');
        child.style.setProperty('textShadow', '0 0 6px #b3d9ff', 'important');
      } else {
        child.style.setProperty('background', 'transparent', 'important');
      }
    });
  }
  
  // 🟡 Apply to all existing _fore elements
  document.querySelectorAll('._fore').forEach(applyForeInnerStyle);
  
  // 🟡 Observe future _fore elements and their children
  const observerForeInner = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('_fore')) applyForeInnerStyle(node);
  
        node.querySelectorAll?.('._fore')?.forEach(applyForeInnerStyle);
      }
    }
  });
  observerForeInner.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Style ._fore with dark blue and children transparent
  function styleForeElement(el) {
    const darkBlue = '#b3d9ff';
  
    el.style.setProperty('background', darkBlue, 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', `0 0 8px ${darkBlue}`, 'important');
  
    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  }
  
  // 🟡 Apply to existing ._fore
  document.querySelectorAll('._fore').forEach(styleForeElement);
  
  // 🟡 Observe and apply to new ._fore elements
  const observerStrictFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList?.contains('_fore')) {
          styleForeElement(node);
        }
  
        node.querySelectorAll?.('._fore')?.forEach(styleForeElement);
      }
    }
  });
  observerStrictFore.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Dark Blue Style for .container-children
  function styleDarkBlueContainer(el) {
    el.style.setProperty('background', 'linear-gradient(135deg, #b3d9ff, #4da6ff)', 'important');
    el.style.setProperty('color', '#003366', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #66b3ff', 'important');
  }
  
  // Apply to existing elements
  document.querySelectorAll('.container-children').forEach(styleDarkBlueContainer);
  
  // Observe and apply to future elements
  const observerContainerChildren = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('container-children')) {
          styleDarkBlueContainer(node);
        }
        node.querySelectorAll?.('.container-children')?.forEach(styleDarkBlueContainer);
      }
    }
  });
  observerContainerChildren.observe(document.body, { childList: true, subtree: true });
  
  // 🟡 Style function for .widget-title
  function styleWidgetTitle(el) {
    el.style.setProperty('background', '#cce6ff', 'important');
    el.style.setProperty('color', '#0066cc', 'important');
    el.style.setProperty('text-shadow', '0 0 6px #b3d9ff', 'important');
    el.style.setProperty('padding', '6px 12px', 'important');
    el.style.setProperty('border-radius', '0.5rem', 'important');
  }
  
  // 🟡 Apply to existing .widget-title elements
  document.querySelectorAll('.widget-title').forEach(styleWidgetTitle);
  
  // 🟡 Observe future .widget-title elements
  const observerWidgetTitle = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('widget-title')) {
          styleWidgetTitle(node);
        }
  
        node.querySelectorAll?.('.widget-title')?.forEach(styleWidgetTitle);
      }
    }
  });
  observerWidgetTitle.observe(document.body, { childList: true, subtree: true });
  
  // Use a unique observer name to avoid conflicts
  const observer_css1h088zk_blue = new MutationObserver(() => {
    document.querySelectorAll('.css-1h088zk').forEach(el => {
      el.style.cssText += `
        background-color: #4da6ff !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 0 10px #66b3ff !important;
      `;
      console.log('Blue style applied:', el);
    });
  });
  
  // Apply immediately in case the element already exists
  document.querySelectorAll('.css-1h088zk').forEach(el => {
    el.style.cssText += `
      background-color: #4da6ff !important;
      color: #ffffff !important;
      border-radius: 8px !important;
      transition: all 0.3s ease !important;
      box-shadow: 0 0 10px #66b3ff !important;
    `;
    console.log('Blue style applied:', el);
  });
  
  // Observe for future elements
  observer_css1h088zk_blue.observe(document.body, {
    childList: true,
    subtree: true,
  });
  
  // Blue colors
  const mainBlue = '#4da6ff';
  const beforeBlue = '#80bfff';
  
  // Add style for ::before only
  const pseudoStyle = document.createElement('style');
  pseudoStyle.textContent = `
    ._unit_name::before {
      background-color: ${beforeBlue} !important;
    }
  `;
  document.head.appendChild(pseudoStyle);
  
  // Function to style all _unit_name elements
  const styleUnitNameBlue = () => {
    document.querySelectorAll('._unit_name').forEach(el => {
      el.style.backgroundColor = mainBlue;
      el.style.color = '#ffffff';
      el.style.borderRadius = '6px';
      el.style.padding = '4px';
      el.style.transition = 'all 0.3s ease';
    });
  };
  
  // Apply to existing elements
  styleUnitNameBlue();
  
  // Watch for new _unit_name elements
  const observer_unit_name_blue = new MutationObserver(() => {
    styleUnitNameBlue();
  });
  observer_unit_name_blue.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Blue styling (color only)
  const applyBlueToMain = () => {
    document.querySelectorAll('.main-18ys6ck').forEach(el => {
      el.style.backgroundColor = '#4da6ff';
      el.style.color = '#ffffff';
      el.style.transition = 'all 0.3s ease';
    });
  };
  
  // Run initially
  applyBlueToMain();
  
  // Watch for new elements
  const observer_main_blue = new MutationObserver(() => {
    applyBlueToMain();
  });
  observer_main_blue.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Hover border color (blue)
  const hoverBorderBlue = '#4da6ff';
  
  // Inject CSS for both classes
  const hoverStyle = document.createElement('style');
  hoverStyle.textContent = `
    .padding:hover,
    .main-5u5jqx:hover {
      border: 2px solid ${hoverBorderBlue} !important;
      transition: border-color 0.3s ease !important;
    }
  `;
  document.head.appendChild(hoverStyle);
  
  // Function to ensure classes are applied
  const applyHoverClasses = () => {
    document.querySelectorAll('.padding, .main-5u5jqx').forEach(el => {
      el.classList.add(...el.classList);
    });
  };
  applyHoverClasses();
  
  // Observe DOM for new elements
  const observer_hover_blue = new MutationObserver(() => {
    applyHoverClasses();
  });
  observer_hover_blue.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Define CSS with gradient and animation
  const styleXzur6n = document.createElement('style');
  styleXzur6n.textContent = `
    @keyframes blueGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    .css-xzur6n {
      background: linear-gradient(270deg, #4da6ff, #80bfff, #3399ff);
      background-size: 600% 600%;
      animation: blueGradientMove 6s ease infinite;
      color: #ffffff !important;
      transition: all 0.3s ease;
      border-radius: 6px;
    }
  `;
  document.head.appendChild(styleXzur6n);
  
  // Apply class styles if already present
  const applyBlueGradient = () => {
    document.querySelectorAll('.css-xzur6n').forEach(el => {
      el.classList.add('css-xzur6n');
    });
  };
  
  applyBlueGradient(); // Immediate
  
  // Observer to handle dynamically added elements
  const observer_xzur6n = new MutationObserver(() => {
    applyBlueGradient();
  });
  observer_xzur6n.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  console.log("🔵 Blue theme script injected");