const applyTricolorHeaderStyle = (header) => {
    header.style.background = 'linear-gradient(135deg, #FF9933, #FFFFFF, #138808)';
    header.style.color = '#000';
    header.style.boxShadow = '0 0 10px rgba(255, 153, 51, 0.7)';
    header.style.transition = 'all 0.3s ease';
};

// Check if header already exists
const existingHeader = document.querySelector('header');
if (existingHeader) {
    applyTricolorHeaderStyle(existingHeader);
} else {
    // Wait for it if not there
    const observer = new MutationObserver((mutations, obs) => {
        const header = document.querySelector('header');
        if (header) {
            applyTricolorHeaderStyle(header);
            obs.disconnect();
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
}

// Base Background
document.body.style.background = '#0a0a0a';
document.body.style.color = '#FFFFFF';

// Universal Link Styling
const tricolorStyle = document.createElement('style');
tricolorStyle.innerHTML = `
    a {
      color: #FF9933 !important;
      text-shadow: 0 0 4px rgba(255, 153, 51, 0.7), 0 0 8px rgba(255, 153, 51, 0.5);
      transition: 0.3s;
    }
    a:hover {
      color: #FFFFFF !important;
    }
    h1, h2, h3, h4, h5, h6 {
      color: #FFFFFF !important;
      text-shadow: 0 0 6px rgba(255, 255, 255, 0.5), 0 0 12px rgba(19, 136, 8, 0.5);
    }
    p {
      color: #CCCCCC !important;
    }
    button, .Button {
      background: linear-gradient(90deg, #FF9933, #FFFFFF, #138808);
      color: black;
      padding: 8px 16px;
      border: none;
      border-radius: 2rem;
      box-shadow: 0 0 10px rgba(255, 153, 51, 0.5);
      cursor: pointer;
      font-weight: bold;
      transition: 0.3s;
    }
    button:hover, .Button:hover {
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.7);
    }

    @keyframes darkGradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    ._active-gradient-animated {
      background: linear-gradient(270deg, #FF9933, #FFFFFF, #138808);
      background-size: 400% 400%;
      animation: darkGradientShift 5s ease infinite;
      color: black !important;
      border-radius: 1rem !important;
    }

    @keyframes tricolorGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    @keyframes thinShineSweep {
      0% { left: -50%; top: -50%; }
      100% { left: 150%; top: 150%; }
    }

    .tricolor-shiny {
      background: linear-gradient(270deg, #FF9933, #FFFFFF, #138808);
      background-size: 400% 400%;
      animation: tricolorGradientMove 6s ease-in-out infinite;
      color: black !important;
      border-radius: 1rem !important;
      position: relative;
      overflow: hidden;
      z-index: 0;
    }

    .tricolor-shiny::after {
      content: '';
      position: absolute;
      width: 150%;
      height: 2px;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
      animation: thinShineSweep 2.5s linear infinite;
      transform: rotate(45deg);
      pointer-events: none;
      z-index: 1;
    }

    .rounded-icon {
      background: linear-gradient(135deg, #0a0a0a, #1a1a1a);
      border-radius: 50%;
      padding: 10px;
      color: #FF9933;
      text-shadow: 0 0 6px rgba(255, 153, 51, 0.7);
      transition: 0.3s;
    }

    .rounded-icon:hover {
      color: #FFFFFF;
      text-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
    }

    .animated-bar {
      background: linear-gradient(270deg, #FF9933, #FFFFFF, #138808);
      background-size: 300% 300%;
      animation: darkGradientShift 6s ease-in-out infinite;
    }

    .Icon-arrow_up {
      background: linear-gradient(135deg, #0a0a0a, #1a1a1a);
      border-radius: 50%;
      padding: 10px;
      color: #FF9933;
      text-shadow: 0 0 6px rgba(255, 153, 51, 0.7);
      transition: 0.3s;
    }

    .Icon-arrow_up:hover {
      color: #FFFFFF;
      text-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
    }
  `;
document.head.appendChild(tricolorStyle);

// Animated glowing gradient text for _main ._label
(function () {
    const el = document.querySelector('._main ._label');
    if (!el) return;

    el.style.backgroundImage = 'linear-gradient(90deg, #FFFFFF, #FF9933, #FFFFFF, #138808, #FFFFFF)';
    el.style.backgroundSize = '300% auto';
    el.style.color = 'transparent';
    el.style.backgroundClip = 'text';
    el.style.webkitBackgroundClip = 'text';
    el.style.fontWeight = 'bold';
    el.style.animation = 'shine 2s linear infinite';
    el.style.textShadow = 'none';
})();

// Apply to common components
const tricolorSelectors = [
    '._top', '._bottom',
    '.main-v2f8c4', '.main-zf0xiu', '.main-1tz8zqw',
    '.main-hp9qcx', '.main-x9v4u5', '.in_container',
    '._clickable', '.Icon-arrow_up', '.fa-play'
];

function applyTricolorTheme(el) {
    if (el.classList.contains('_top') || el.classList.contains('_bottom')) {
        el.classList.add('animated-bar');
        el.style.color = '#FFFFFF';
        el.querySelectorAll('*').forEach(child => {
            child.style.color = '#FFFFFF';
            child.style.textShadow = '0 0 6px rgba(255, 153, 51, 0.7)';
        });
        return;
    }

    el.style.background = 'linear-gradient(135deg, #0a0a0a, #1a1a1a)';
    el.style.color = '#FFFFFF';
    el.style.borderRadius = '1rem';
    el.style.textShadow = '0 0 6px rgba(255, 153, 51, 0.5)';

    if (el.classList.contains('Icon-arrow_up') || el.classList.contains('fa-play')) {
        el.classList.add('rounded-icon');
    }

    el.querySelectorAll('*').forEach(child => {
        child.style.color = '#FFFFFF';
        child.style.textShadow = '0 0 6px rgba(255, 153, 51, 0.5)';
    });
}

document.querySelectorAll(tricolorSelectors.join(',')).forEach(applyTricolorTheme);

const tricolorObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
                if (tricolorSelectors.some(sel => node.matches(sel))) {
                    applyTricolorTheme(node);
                }
                node.querySelectorAll(tricolorSelectors.join(',')).forEach(applyTricolorTheme);
            }
        }
    }
});
tricolorObserver.observe(document.body, { childList: true, subtree: true });

// _active animation
const tricolorStyledElements = new WeakMap();
setInterval(() => {
    document.querySelectorAll('._active').forEach(el => {
        if (!el.classList.contains('_active-gradient-animated')) {
            if (!tricolorStyledElements.has(el)) {
                tricolorStyledElements.set(el, {
                    background: el.style.background,
                    color: el.style.color,
                    borderRadius: el.style.borderRadius,
                });
            }
            el.classList.add('_active-gradient-animated');
        }
    });
}, 300);

// Tricolor Shine Effect
function applyTricolorShiny(el) {
    if (!el.classList.contains('tricolor-shiny')) {
        el.classList.add('tricolor-shiny');
    }
}

const tricolorTarget = document.querySelector('.main-y3ei6l');
if (tricolorTarget) applyTricolorShiny(tricolorTarget);

const tricolorWatcher = new MutationObserver(() => {
    const el = document.querySelector('.main-y3ei6l');
    if (el) {
        applyTricolorShiny(el);
        tricolorWatcher.disconnect();
    }
});
tricolorWatcher.observe(document.body, { childList: true, subtree: true });

// _today styling
function styleTodayElement(el) {
    el.style.background = 'linear-gradient(135deg, #FF9933, #138808)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px rgba(255, 153, 51, 0.7)';
    el.style.fontWeight = 'bold';
}
document.querySelectorAll('._today').forEach(styleTodayElement);
const observerToday = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
                if (node.classList.contains('_today')) {
                    styleTodayElement(node);
                }
                node.querySelectorAll('._today').forEach(styleTodayElement);
            }
        }
    }
});
observerToday.observe(document.body, { childList: true, subtree: true });


//////_fore ------------
// Apply to existing elements
document.querySelectorAll('._fore').forEach(el => {
    // Style the ._fore element itself
    el.style.setProperty('background', '#000000', 'important');
    el.style.setProperty('color', '#FFFFFF', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', '0 0 10px rgba(255, 153, 51, 0.3)', 'important');

    // Force all children to have black background and white text
    el.querySelectorAll('*').forEach(child => {
        child.style.setProperty('background', '#000000', 'important');
        child.style.setProperty('color', '#FFFFFF', 'important');
        child.style.setProperty('border-color', '#FFFFFF', 'important');
    });
});

// Observe and style new elements dynamically
const observerFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType === 1) {
                if (node.classList.contains('_fore')) {
                    // Style the main ._fore element
                    node.style.setProperty('background', '#000000', 'important');
                    node.style.setProperty('color', '#FFFFFF', 'important');
                    node.style.setProperty('padding', '12px', 'important');
                    node.style.setProperty('border-radius', '1rem', 'important');
                    node.style.setProperty('box-shadow', '0 0 10px rgba(255, 153, 51, 0.3)', 'important');
                    
                    // Style all children
                    node.querySelectorAll('*').forEach(child => {
                        child.style.setProperty('background', '#000000', 'important');
                        child.style.setProperty('color', '#FFFFFF', 'important');
                        child.style.setProperty('border-color', '#FFFFFF', 'important');
                    });
                }
                
                // Handle any ._fore elements within added nodes
                node.querySelectorAll('._fore').forEach(el => {
                    el.style.setProperty('background', '#000000', 'important');
                    el.style.setProperty('color', '#FFFFFF', 'important');
                    el.style.setProperty('padding', '12px', 'important');
                    el.style.setProperty('border-radius', '1rem', 'important');
                    el.style.setProperty('box-shadow', '0 0 10px rgba(255, 153, 51, 0.3)', 'important');
                    
                    // Style all children
                    el.querySelectorAll('*').forEach(child => {
                        child.style.setProperty('background', '#000000', 'important');
                        child.style.setProperty('color', '#FFFFFF', 'important');
                        child.style.setProperty('border-color', '#FFFFFF', 'important');
                    });
                });
            }
        }
    }
});
observerFore.observe(document.body, { childList: true, subtree: true });

// Tricolor STYLING FOR _day AND _note
function styleTricolorDay(el) {
    el.style.background = 'linear-gradient(135deg, #FF9933, #FFFFFF)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px rgba(255, 153, 51, 0.7)';
    el.style.fontWeight = 'bold';
}
function styleTricolorNote(el) {
    el.style.background = 'linear-gradient(135deg, #FFFFFF, #138808)';
    el.style.color = '#000';
    el.style.borderRadius = '0.75rem';
    el.style.padding = '8px';
    el.style.boxShadow = '0 0 10px rgba(19, 136, 8, 0.7)';
}
document.querySelectorAll('._day').forEach(styleTricolorDay);
document.querySelectorAll('._note').forEach(styleTricolorNote);
const observerTricolor = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;
            if (node.classList.contains('_day')) styleTricolorDay(node);
            if (node.classList.contains('_note')) styleTricolorNote(node);
            node.querySelectorAll('._day').forEach(styleTricolorDay);
            node.querySelectorAll('._note').forEach(styleTricolorNote);
        }
    }
});
observerTricolor.observe(document.body, { childList: true, subtree: true });

// Tricolor calendar icon
function styleTricolorCalendar(el) {
    el.style.color = '#FF9933';
    el.style.textShadow = '0 0 6px rgba(255, 153, 51, 0.7)';
    el.style.background = 'none';
}
document.querySelectorAll('.fa-calendar-alt').forEach(styleTricolorCalendar);
const calendarObserverTricolor = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;
            if (node.classList.contains('fa-calendar-alt')) {
                styleTricolorCalendar(node);
            }
            node.querySelectorAll('.fa-calendar-alt').forEach(styleTricolorCalendar);
        }
    }
});
calendarObserverTricolor.observe(document.body, { childList: true, subtree: true });

// Style for .fa-calendar-star
const style = document.createElement('style');
style.textContent = `
    .fa-calendar-star,
    .fa-calendar-star::before {
      color: #FF9933 !important;
      text-shadow: 0 0 6px rgba(255, 153, 51, 0.7) !important;
    }
  `;
document.head.appendChild(style);

// Style _dots elements to saffron
function styleTricolorDots(el) {
    el.style.color = '#FF9933';
    el.style.textShadow = '0 0 4px rgba(255, 153, 51, 0.7)';
}

// Apply to existing ._dots elements
document.querySelectorAll('._dots').forEach(styleTricolorDots);

// Observe for future ._dots elements
const observerDots = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;

            if (node.classList.contains('_dots')) styleTricolorDots(node);
            node.querySelectorAll('._dots').forEach(styleTricolorDots);
        }
    }
});
observerDots.observe(document.body, { childList: true, subtree: true });

// Font Awesome Icons to saffron
function styleAllFontAwesome(el) {
    el.style.setProperty('color', '#FF9933', 'important');
    el.style.setProperty('text-shadow', '0 0 6px rgba(255, 153, 51, 0.7)', 'important');
}
document.querySelectorAll('.fa, .fas, .far, .fal, .fab').forEach(styleAllFontAwesome);
const observerFA = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;
            if (node.classList?.toString().match(/\bfa[bsrl]?\b/)) {
                styleAllFontAwesome(node);
            }
            node.querySelectorAll?.('.fa, .fas, .far, .fal, .fab')?.forEach(styleAllFontAwesome);
        }
    }
});
observerFA.observe(document.body, { childList: true, subtree: true });

// Tricolor Background for .main-1k6w26b
const styleMain = document.createElement('style');
styleMain.innerHTML = `
    .main-1k6w26b {
      background: linear-gradient(135deg, #1a1a1a, #0a0a0a) !important;
      color: #FF9933 !important;
      border-radius: 0.75rem !important;
      box-shadow: 0 0 10px rgba(255, 153, 51, 0.5) !important;
      padding: 12px !important;
      transition: all 0.3s ease !important;
    }
    .main-1k6w26b:hover {
      box-shadow: 0 0 14px rgba(255, 153, 51, 0.7) !important;
    }
  `;
document.head.appendChild(styleMain);

// Tricolor Style for .container-children
function styleTricolorContainer(el) {
    el.style.setProperty('background', 'linear-gradient(135deg, #1a1a1a, #0a0a0a)', 'important');
    el.style.setProperty('color', '#FFFFFF', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('box-shadow', '0 0 10px rgba(255, 153, 51, 0.5)', 'important');
}

// Apply to existing elements
document.querySelectorAll('.container-children').forEach(styleTricolorContainer);

// Observe and apply to future elements
const observerContainerChildren = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;
            if (node.classList?.contains('container-children')) {
                styleTricolorContainer(node);
            }
            node.querySelectorAll?.('.container-children')?.forEach(styleTricolorContainer);
        }
    }
});
observerContainerChildren.observe(document.body, { childList: true, subtree: true });

// Style function for .widget-title
function styleWidgetTitle(el) {
    el.style.setProperty('background', 'linear-gradient(135deg, #FF9933, #138808)', 'important');
    el.style.setProperty('color', '#000', 'important');
    el.style.setProperty('padding', '6px 12px', 'important');
    el.style.setProperty('border-radius', '0.5rem', 'important');
    el.style.setProperty('box-shadow', '0 0 8px rgba(255, 153, 51, 0.7)', 'important');
}

// Apply to existing .widget-title elements
document.querySelectorAll('.widget-title').forEach(styleWidgetTitle);

// Observe future .widget-title elements
const observerWidgetTitle = new MutationObserver(mutations => {
    for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
            if (node.nodeType !== 1) continue;

            if (node.classList.contains('widget-title')) {
                styleWidgetTitle(node);
            }

            node.querySelectorAll?.('.widget-title')?.forEach(styleWidgetTitle);
        }
    }
});
observerWidgetTitle.observe(document.body, { childList: true, subtree: true });

// Add the particle effect
(() => {
    const canvas = document.createElement('canvas');
    canvas.style.position = 'fixed';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.zIndex = '9999';
    canvas.style.pointerEvents = 'none';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d');
    const colors = ['#FF9933', '#FFFFFF', '#138808'];
    let particles = [];
    let particleCount = Math.min(50, Math.floor(window.innerWidth / 20));

    function Particle(x, y) {
        this.x = x || Math.random() * canvas.width;
        this.y = y || Math.random() * canvas.height;
        this.radius = Math.random() * 3 + 1;
        this.color = colors[Math.floor(Math.random() * colors.length)];
        this.speed = Math.random() * 1 + 0.5;
        this.angle = Math.random() * Math.PI * 2;
        this.alpha = 0.5 + Math.random() * 0.5;
    }

    function init() {
        particles = [];
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        for (let i = 0; i < particles.length; i++) {
            const p = particles[i];
            
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.fill();
            
            p.x += Math.cos(p.angle) * p.speed;
            p.y += Math.sin(p.angle) * p.speed;
            
            if (p.x < 0 || p.x > canvas.width || p.y < 0 || p.y > canvas.height) {
                if (Math.random() > 0.5) {
                    p.x = Math.random() * canvas.width;
                    p.y = -10;
                } else {
                    p.x = -10;
                    p.y = Math.random() * canvas.height;
                }
            }
        }
        
        requestAnimationFrame(animate);
    }

    function handleResize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        particleCount = Math.min(50, Math.floor(window.innerWidth / 20));
        init();
    }

    // Initialize with delay
    setTimeout(() => {
        init();
        animate();
        window.addEventListener('resize', handleResize);
    }, 500);

    // Add particles on click
    window.addEventListener('click', (e) => {
        for (let i = 0; i < 15; i++) {
            particles.push(new Particle(e.clientX, e.clientY));
        }
    });
})();






(() => {
  // Only define the function if it's not already defined
  if (typeof applyTricolorHeaderStyle !== 'function') {
    function applyTricolorHeaderStyle(header) {
      header.style.background = 'linear-gradient(to right, orange, white, green)';
      header.style.color = 'black';
      header.style.textAlign = 'center';
      header.style.fontWeight = 'bold';
    }
  }

  const tryApplyHeader = setInterval(() => {
    const header = document.querySelector('header');
    if (header && !header.dataset.tricolored) {
      applyTricolorHeaderStyle(header);
      header.dataset.tricolored = "true";
      clearInterval(tryApplyHeader);
    }
  }, 1000);

  function fixElementColors(el) {
    const styles = window.getComputedStyle(el);
    const bg = styles.backgroundColor;
    const color = styles.color;

    if (bg === 'rgb(45, 51, 59)') {
      el.style.backgroundColor = 'black';
      if (color === 'rgb(0, 0, 0)') {
        el.style.color = 'white';
      }
    }
  }

  document.querySelectorAll('*').forEach(fixElementColors);

  const bgFixObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) {
            fixElementColors(node);
            node.querySelectorAll('*').forEach(fixElementColors);
          }
        });
      } else if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
        fixElementColors(mutation.target);
      }
    }
  });

  bgFixObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style'],
  });

  function isBlackColor(rgb) {
    const match = rgb?.match(/\d+/g);
    if (!match || match.length < 3) return false;
    const [r, g, b] = match.map(Number);
    return r < 50 && g < 50 && b < 50;
  }

  function fixBlackTextInLauncher(launcher) {
    launcher.querySelectorAll('*').forEach(el => {
      const color = getComputedStyle(el).color;
      if (isBlackColor(color)) {
        el.style.color = 'white';
      }
    });
  }

  const existingLauncher = document.querySelector('.launcher');
  if (existingLauncher) {
    fixBlackTextInLauncher(existingLauncher);
  }

  const launcherFixObserver = new MutationObserver(mutations => {
    for (const m of mutations) {
      m.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.classList?.contains('launcher')) {
            fixBlackTextInLauncher(node);
          } else if (node.querySelector?.('.launcher')) {
            fixBlackTextInLauncher(node.querySelector('.launcher'));
          }
        }
      });

      if (m.target.closest && m.target.closest('.launcher')) {
        fixBlackTextInLauncher(m.target.closest('.launcher'));
      }
    }
  });

  launcherFixObserver.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['style'],
  });
})();


(() => {
  const CLASS_NAME = 'css-1h088zk';

  // Apply tricolor gradient to an element
  function applyTricolorStyle(el) {
    el.style.background = 'linear-gradient(to right, orange, white, green)';
    el.style.color = 'black'; // optional: adjust text for contrast
    el.style.fontWeight = 'bold';
  }

  // Apply to all existing elements with the class
  document.querySelectorAll(`.${CLASS_NAME}`).forEach(applyTricolorStyle);

  // Observe for future elements or changes
  const observer = new MutationObserver(mutations => {
    for (const m of mutations) {
      m.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.classList?.contains(CLASS_NAME)) {
            applyTricolorStyle(node);
          }
          // Also check inside it
          node.querySelectorAll?.(`.${CLASS_NAME}`).forEach(applyTricolorStyle);
        }
      });

      // Style changes on existing elements
      if (m.target?.classList?.contains(CLASS_NAME)) {
        applyTricolorStyle(m.target);
      }
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class'],
  });
})();



(() => {
  const styleId = 'cool-tricolor-hover-style';
  if (!document.getElementById(styleId)) {
    const style = document.createElement('style');
    style.id = styleId;
    style.textContent = `
      .main-uv8k3y {
        background-color: black !important;
        position: relative;
        transition: border 0.3s ease;
        z-index: 0;
      }

      .main-uv8k3y::before {
        content: "";
        position: absolute;
        top: -3px; left: -3px; right: -3px; bottom: -3px;
        background: linear-gradient(270deg, orange, white, green, orange);
        background-size: 600% 600%;
        z-index: -1;
        border-radius: inherit;
        opacity: 0;
        transition: opacity 0.3s ease;
        animation: shimmer 3s ease infinite;
        pointer-events: none;
      }

      .main-uv8k3y:hover::before {
        opacity: 1;
      }

      @keyframes shimmer {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
      }
    `;
    document.head.appendChild(style);
  }

  const applyStyles = () => {
    const els = document.querySelectorAll('.main-uv8k3y');
    els.forEach(el => el.classList.add('main-uv8k3y'));
  };

  applyStyles();

  const observer = new MutationObserver(mutations => {
    mutations.forEach(m => {
      m.addedNodes.forEach(n => {
        if (n.nodeType === 1 && n.classList.contains('main-uv8k3y')) {
          n.classList.add('main-uv8k3y');
        }
      });
    });
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();


console.log(" Tri color theme Sucess");


















(() => {
    // Canvas setup
    const canvas = document.createElement('canvas');
    Object.assign(canvas.style, {
      position: 'fixed',
      top: '0',
      left: '0',
      width: '100vw',
      height: '100vh',
      pointerEvents: 'none',
      zIndex: '9999'
    });
    document.body.appendChild(canvas);
  
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  
    // Configuration
    const colors = ['#FF9933', '#FFFFFF', '#138808'];
    const particles = [];
    let chaosMode = false;
    let lastFrameTime = 0;
    const frameRate = 60;
    const frameInterval = 1000 / frameRate;
  
    // Particle types
    const PARTICLE_TYPES = {
      BASIC: 0,
      RING: 1,
      LIGHTNING: 2,
      FIREWORK: 3,
      TRAIL: 4,
      STAR: 5,
      COMET: 6,
      FLOWER: 7,
      CHAKRA: 8
    };
  
    class Particle {
      constructor(x, y, type = PARTICLE_TYPES.BASIC, options = {}) {
        this.x = x;
        this.y = y;
        this.type = type;
        this.color = colors[Math.floor(Math.random() * colors.length)];
        this.alpha = 1;
        this.lifespan = Math.random() * 100 + 100;
        this.age = 0;
        this.trail = [];
        this.options = {
          size: Math.random() * 2 + 1,
          speed: Math.random() * 2 + 1,
          direction: Math.random() * Math.PI * 2,
          ...options
        };
  
        this.initBehavior();
      }
  
      initBehavior() {
        switch (this.type) {
          case PARTICLE_TYPES.RING:
            this.options.size = 5;
            this.options.growthRate = 2;
            break;
          case PARTICLE_TYPES.LIGHTNING:
            this.options.size = 2;
            this.options.speed = 0;
            this.lifespan = 30;
            break;
          case PARTICLE_TYPES.FIREWORK:
            this.options.size = Math.random() * 3 + 2;
            this.lifespan = 120;
            break;
          case PARTICLE_TYPES.TRAIL:
            this.options.size = Math.random() * 1.5 + 0.5;
            this.lifespan = 80;
            break;
          case PARTICLE_TYPES.STAR:
            this.options.points = 5;
            this.options.size = Math.random() * 4 + 3;
            this.lifespan = 150;
            break;
          case PARTICLE_TYPES.COMET:
            this.options.size = Math.random() * 4 + 2;
            this.options.speed = Math.random() * 3 + 2;
            this.options.direction = Math.random() * Math.PI * 2;
            this.lifespan = 200;
            this.trailLength = Math.floor(Math.random() * 15 + 10);
            break;
          case PARTICLE_TYPES.FLOWER:
            this.options.petals = Math.floor(Math.random() * 4 + 5);
            this.options.size = Math.random() * 8 + 5;
            this.lifespan = 180;
            break;
          case PARTICLE_TYPES.CHAKRA:
            this.options.size = Math.random() * 10 + 10;
            this.options.spokes = 24;
            this.lifespan = 200;
            break;
        }
      }
  
      update() {
        this.age++;
        this.alpha = 1 - (this.age / this.lifespan);
        
        // Update position based on type
        if (this.type !== PARTICLE_TYPES.RING && this.type !== PARTICLE_TYPES.LIGHTNING) {
          this.x += Math.cos(this.options.direction) * this.options.speed;
          this.y += Math.sin(this.options.direction) * this.options.speed;
        }
        
        // Special behaviors
        if (this.type === PARTICLE_TYPES.RING) {
          this.options.size += this.options.growthRate;
        }
        
        if (this.type === PARTICLE_TYPES.COMET || this.type === PARTICLE_TYPES.TRAIL) {
          this.trail.push({x: this.x, y: this.y, alpha: this.alpha});
          if (this.trail.length > (this.trailLength || 10)) this.trail.shift();
        }
        
        // Apply gravity to some particles
        if (this.type === PARTICLE_TYPES.FIREWORK || this.type === PARTICLE_TYPES.COMET) {
          this.options.direction += 0.02;
          this.options.speed *= 0.98;
        }
      }
  
      draw() {
        ctx.save();
        ctx.globalAlpha = this.alpha;
        ctx.fillStyle = this.color;
        ctx.strokeStyle = this.color;
        
        // Draw trail if applicable
        if (this.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(this.trail[0].x, this.trail[0].y);
          for (let i = 1; i < this.trail.length; i++) {
            ctx.globalAlpha = this.trail[i].alpha * (i / this.trail.length);
            ctx.lineTo(this.trail[i].x, this.trail[i].y);
          }
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        
        // Draw the particle based on its type
        switch (this.type) {
          case PARTICLE_TYPES.BASIC:
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.options.size, 0, Math.PI * 2);
            ctx.fill();
            break;
            
          case PARTICLE_TYPES.RING:
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.options.size, 0, Math.PI * 2);
            ctx.lineWidth = 2;
            ctx.stroke();
            break;
            
          case PARTICLE_TYPES.LIGHTNING:
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.options.size, 0, Math.PI * 2);
            ctx.fill();
            break;
            
          case PARTICLE_TYPES.STAR:
            this.drawStar(this.x, this.y, this.options.points, this.options.size, this.options.size * 0.5);
            ctx.fill();
            break;
            
          case PARTICLE_TYPES.COMET:
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.options.size, 0, Math.PI * 2);
            ctx.fill();
            break;
            
          case PARTICLE_TYPES.FLOWER:
            this.drawFlower(this.x, this.y, this.options.petals, this.options.size);
            ctx.fill();
            break;
            
          case PARTICLE_TYPES.CHAKRA:
            this.drawChakra(this.x, this.y, this.options.size, this.options.spokes);
            ctx.stroke();
            break;
        }
        
        ctx.restore();
      }
      
      drawStar(cx, cy, spikes, outerRadius, innerRadius) {
        let rot = Math.PI/2*3;
        let x = cx;
        let y = cy;
        let step = Math.PI/spikes;
  
        ctx.beginPath();
        ctx.moveTo(cx, cy - outerRadius);
        
        for(let i = 0; i < spikes; i++) {
          x = cx + Math.cos(rot) * outerRadius;
          y = cy + Math.sin(rot) * outerRadius;
          ctx.lineTo(x, y);
          rot += step;
  
          x = cx + Math.cos(rot) * innerRadius;
          y = cy + Math.sin(rot) * innerRadius;
          ctx.lineTo(x, y);
          rot += step;
        }
        
        ctx.lineTo(cx, cy - outerRadius);
        ctx.closePath();
      }
      
      drawFlower(cx, cy, petals, radius) {
        ctx.beginPath();
        for(let i = 0; i < petals * 2; i++) {
          const angle = (i * Math.PI) / petals;
          const petalRadius = i % 2 === 0 ? radius : radius * 0.5;
          const x = cx + Math.cos(angle) * petalRadius;
          const y = cy + Math.sin(angle) * petalRadius;
          
          if(i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.closePath();
      }
      
      drawChakra(cx, cy, radius, spokes) {
        // Outer circle
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();
        
        // Inner circle
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.5, 0, Math.PI * 2);
        ctx.stroke();
        
        // Spokes
        for(let i = 0; i < spokes; i++) {
          const angle = (i * Math.PI * 2) / spokes;
          ctx.beginPath();
          ctx.moveTo(cx, cy);
          ctx.lineTo(
            cx + Math.cos(angle) * radius,
            cy + Math.sin(angle) * radius
          );
          ctx.stroke();
        }
      }
    }
  
    // Effect functions
    const effects = {
      flicker() {
        const flick = document.createElement('div');
        Object.assign(flick.style, {
          position: 'fixed',
          top: '0',
          left: '0',
          width: '100vw',
          height: '100vh',
          background: colors[Math.floor(Math.random() * colors.length)],
          opacity: Math.random() * 0.3 + 0.1,
          zIndex: '9998',
          transition: 'opacity 0.1s',
          pointerEvents: 'none'
        });
        document.body.appendChild(flick);
        setTimeout(() => flick.remove(), 100);
      },
      
      spawnBurst(x, y, count = 30) {
        for (let i = 0; i < count; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = Math.random() * 3 + 1;
          const type = Math.random() < 0.3 ? PARTICLE_TYPES.STAR : PARTICLE_TYPES.BASIC;
          
          particles.push(new Particle(
            x, y, type, {
              direction: angle,
              speed: speed,
              size: type === PARTICLE_TYPES.STAR ? Math.random() * 3 + 2 : Math.random() * 2 + 1
            }
          ));
        }
      },
      
      spawnRings(x, y, count = 3) {
        for (let i = 0; i < count; i++) {
          particles.push(new Particle(x, y, PARTICLE_TYPES.RING, {
            size: i * 5,
            growthRate: 1.5 + Math.random()
          }));
        }
      },
      
      spawnLightning() {
        const x = Math.random() * canvas.width;
        const segments = 10 + Math.floor(Math.random() * 10);
        const dx = (Math.random() - 0.5) * 40;
        
        for (let i = 0; i < segments; i++) {
          particles.push(new Particle(
            x + dx * i,
            (canvas.height / segments) * i,
            PARTICLE_TYPES.LIGHTNING
          ));
        }
      },
      
      spawnFirework() {
        const x = Math.random() * canvas.width;
        const y = canvas.height;
        const peak = Math.random() * canvas.height * 0.4 + canvas.height * 0.2;
        
        // Launch particle
        const launchParticle = new Particle(x, y, PARTICLE_TYPES.COMET, {
          direction: -Math.PI/2,
          speed: 5,
          size: 3
        });
        particles.push(launchParticle);
        
        // Explode at peak
        setTimeout(() => {
          for (let i = 0; i < 60; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 4 + 1;
            const type = Math.random() < 0.3 ? 
              (Math.random() < 0.5 ? PARTICLE_TYPES.STAR : PARTICLE_TYPES.FLOWER) : 
              PARTICLE_TYPES.BASIC;
            
            particles.push(new Particle(
              x, peak, type, {
                direction: angle,
                speed: speed,
                size: type === PARTICLE_TYPES.STAR ? Math.random() * 3 + 2 : 
                      type === PARTICLE_TYPES.FLOWER ? Math.random() * 6 + 4 : 
                      Math.random() * 2 + 1
              }
            ));
          }
        }, (y - peak) / 5 * 16);
      },
      
      spawnComet() {
        const side = Math.floor(Math.random() * 4);
        let x, y, angle;
        
        switch(side) {
          case 0: // top
            x = Math.random() * canvas.width;
            y = -20;
            angle = Math.random() * Math.PI * 0.6 + Math.PI * 0.2;
            break;
          case 1: // right
            x = canvas.width + 20;
            y = Math.random() * canvas.height;
            angle = Math.random() * Math.PI * 0.6 + Math.PI * 0.7;
            break;
          case 2: // bottom
            x = Math.random() * canvas.width;
            y = canvas.height + 20;
            angle = Math.random() * Math.PI * 0.6 + Math.PI * 1.2;
            break;
          case 3: // left
            x = -20;
            y = Math.random() * canvas.height;
            angle = Math.random() * Math.PI * 0.6 + Math.PI * 1.7;
            break;
        }
        
        particles.push(new Particle(x, y, PARTICLE_TYPES.COMET, {
          direction: angle,
          speed: Math.random() * 3 + 2,
          size: Math.random() * 4 + 2
        }));
      },
      
      spawnChakra() {
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        particles.push(new Particle(x, y, PARTICLE_TYPES.CHAKRA, {
          size: Math.random() * 30 + 20,
          spokes: 24
        }));
      },
      
      spawnFlowerField() {
        const count = 10 + Math.floor(Math.random() * 20);
        for (let i = 0; i < count; i++) {
          const x = Math.random() * canvas.width;
          const y = Math.random() * canvas.height;
          particles.push(new Particle(x, y, PARTICLE_TYPES.FLOWER, {
            size: Math.random() * 15 + 5,
            petals: Math.floor(Math.random() * 5 + 4)
          }));
        }
      }
    };
  
    // Animation loop with frame rate control
    function animate(timestamp) {
      if (!lastFrameTime) lastFrameTime = timestamp;
      const elapsed = timestamp - lastFrameTime;
      
      if (elapsed > frameInterval) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Update and draw particles
        for (let i = particles.length - 1; i >= 0; i--) {
          particles[i].update();
          particles[i].draw();
          
          if (particles[i].age >= particles[i].lifespan) {
            particles.splice(i, 1);
          }
        }
        
        lastFrameTime = timestamp - (elapsed % frameInterval);
      }
      
      requestAnimationFrame(animate);
    }
  
    // Chaos mode activation
    function triggerChaosMode() {
      if (chaosMode) return;
      chaosMode = true;
      
      // Initial flicker
      effects.flicker();
      
      // Create a burst of effects
      const effectsList = [
        effects.spawnLightning,
        effects.spawnFirework,
        effects.spawnComet,
        effects.spawnChakra,
        effects.spawnFlowerField
      ];
      
      const duration = 10000; // 10 seconds of chaos
      const startTime = Date.now();
      
      const chaosInterval = setInterval(() => {
        if (Date.now() - startTime > duration) {
          clearInterval(chaosInterval);
          chaosMode = false;
          return;
        }
        
        // Randomly pick and execute effects
        const effect = effectsList[Math.floor(Math.random() * effectsList.length)];
        effect();
        
        // Occasionally flicker
        if (Math.random() < 0.3) {
          effects.flicker();
        }
        
        // Add some basic particles
        if (Math.random() < 0.7) {
          for (let i = 0; i < 20; i++) {
            particles.push(new Particle(
              Math.random() * canvas.width,
              Math.random() * canvas.height,
              Math.random() < 0.2 ? PARTICLE_TYPES.STAR : PARTICLE_TYPES.BASIC
            ));
          }
        }
      }, 200);
    }
  
    // Event listeners
    window.addEventListener('mousemove', (e) => {
      if (!chaosMode) {
        for (let i = 0; i < 3; i++) {
          particles.push(new Particle(e.clientX, e.clientY, PARTICLE_TYPES.TRAIL, {
            direction: Math.random() * Math.PI * 2,
            speed: Math.random() * 1.5,
            size: Math.random() * 1.5 + 0.5
          }));
        }
      }
    });
  
    window.addEventListener('click', (e) => {
      if (chaosMode) return;
      effects.spawnBurst(e.clientX, e.clientY);
      effects.spawnRings(e.clientX, e.clientY);
    });
  
    window.addEventListener('resize', () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    });
  
    // Create chaos button
    const chaosBtn = document.createElement('button');
    Object.assign(chaosBtn.style, {
      position: 'fixed',
      bottom: '20px',
      left: '20px',
      padding: '12px 24px',
      background: 'linear-gradient(135deg, #FF9933, #FFFFFF, #138808)',
      color: '#000',
      fontWeight: 'bold',
      fontSize: '16px',
      zIndex: '10000',
      border: 'none',
      borderRadius: '50px',
      cursor: 'pointer',
      boxShadow: '0 4px 15px rgba(0, 0, 0, 0.2)',
      transition: 'transform 0.2s, box-shadow 0.2s'
    });
    chaosBtn.innerText = '🇮🇳 TRI-COLOR CHAOS 🇮🇳';
    document.body.appendChild(chaosBtn);
  
    // Button hover effects
    chaosBtn.addEventListener('mouseenter', () => {
      chaosBtn.style.transform = 'scale(1.05)';
      chaosBtn.style.boxShadow = '0 6px 20px rgba(0, 0, 0, 0.3)';
    });
  
    chaosBtn.addEventListener('mouseleave', () => {
      chaosBtn.style.transform = 'scale(1)';
      chaosBtn.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.2)';
    });
  
    chaosBtn.addEventListener('click', () => {
      chaosBtn.style.transform = 'scale(0.95)';
      setTimeout(() => {
        chaosBtn.style.transform = 'scale(1)';
        triggerChaosMode();
      }, 200);
    });
  
    // Start animation
    animate();
  })();


