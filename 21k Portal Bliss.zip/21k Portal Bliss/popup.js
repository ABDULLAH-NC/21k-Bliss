document.addEventListener('DOMContentLoaded', () => {
  const select = document.getElementById('themeSelect');

  if (!select) {
    console.error('themeSelect dropdown not found in popup.html!');
    return;
  }

  // Set initial value from storage
  chrome.storage.sync.get('selectedTheme', (data) => {
    select.value = data.selectedTheme || 'none';
  });

  select.addEventListener('change', () => {
    const selectedTheme = select.value;

    chrome.storage.sync.set({ selectedTheme });

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length > 0 && tabs[0].id) {
        chrome.tabs.sendMessage(tabs[0].id, { theme: selectedTheme });
      }
    });
  });
});
