(() => {
  const applyGoldenHeaderStyle = (header) => {
    if (!header || header.dataset.goldenStyled === "true") return;

    header.style.background = 'linear-gradient(135deg, #b8860b, #daa520)';
    header.style.color = '#fff8dc';
    header.style.boxShadow = '0 0 10px #d4af37';
    header.style.transition = 'all 0.3s ease';

    // Prevent restyling if this runs again
    header.dataset.goldenStyled = "true";
  };

  const findAndStyleHeader = () => {
    const header = document.querySelector('header');
    if (header) applyGoldenHeaderStyle(header);
  };

  // Try to apply immediately if possible
  findAndStyleHeader();

  // Setup a robust observer to handle future changes
  const observer = new MutationObserver(() => {
    findAndStyleHeader();
  });

  observer.observe(document.documentElement || document.body, {
    childList: true,
    subtree: true,
  });

  // Optional: Re-run styling on window load just in case
  window.addEventListener('load', findAndStyleHeader);
})();





// Base Background
document.body.style.background = '#2b1b00';
document.body.style.color = '#ffe699';

// Universal Link Styling
const goldenStyle = document.createElement('style');
goldenStyle.innerHTML = `
  a {
    color: #ffcc33 !important;
    text-shadow: 0 0 4px #ffb300, 0 0 8px #ff8f00;
    transition: 0.3s;
  }
  a:hover {
    color: #ffffff !important;
  }
  h1, h2, h3, h4, h5, h6 {
    color: #ffdb4d !important;
    text-shadow: 0 0 6px #ffb300, 0 0 12px #ff9800;
  }
  p {
    color: #ffe699 !important;
  }
  button, .Button {
    background: linear-gradient(90deg, #ffb300, #ffd740);
    color: black;
    padding: 8px 16px;
    border: none;
    border-radius: 2rem;
    box-shadow: 0 0 10px #ffca28;
    cursor: pointer;
    font-weight: bold;
    transition: 0.3s;
  }
  button:hover, .Button:hover {
    box-shadow: 0 0 20px #ffe082;
  }

  @keyframes darkGradientShift {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  ._active-gradient-animated {
    background: linear-gradient(270deg, #ffb300, #2b1b00);
    background-size: 400% 400%;
    animation: darkGradientShift 5s ease infinite;
    color: white !important;
    border-radius: 1rem !important;
  }

  @keyframes goldenGradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  @keyframes thinShineSweep {
    0% { left: -50%; top: -50%; }
    100% { left: 150%; top: 150%; }
  }

  .golden-shiny {
    background: linear-gradient(270deg, #ffb300, #2b1b00, #ffb300);
    background-size: 400% 400%;
    animation: goldenGradientMove 6s ease-in-out infinite;
    color: white !important;
    border-radius: 1rem !important;
    position: relative;
    overflow: hidden;
    z-index: 0;
  }

  .golden-shiny::after {
    content: '';
    position: absolute;
    width: 150%;
    height: 2px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
    animation: thinShineSweep 2.5s linear infinite;
    transform: rotate(45deg);
    pointer-events: none;
    z-index: 1;
  }

  .rounded-icon {
    background: linear-gradient(135deg, #2b1b00, #3b2900);
    border-radius: 50%;
    padding: 10px;
    color: #ffcc33;
    text-shadow: 0 0 6px #ffb300;
    transition: 0.3s;
  }

  .rounded-icon:hover {
    color: #ffffff;
    text-shadow: 0 0 10px #ffeb99;
  }

  .animated-bar {
    background: linear-gradient(270deg, #ffb300, #3b2900);
    background-size: 300% 300%;
    animation: darkGradientShift 6s ease-in-out infinite;
  }

  .Icon-arrow_up {
    background: linear-gradient(135deg, #2b1b00, #3b2900);
    border-radius: 50%;
    padding: 10px;
    color: #ffcc33;
    text-shadow: 0 0 6px #ffb300;
    transition: 0.3s;
  }

  .Icon-arrow_up:hover {
    color: #ffffff;
    text-shadow: 0 0 10px #ffeb99;
  }
`;
document.head.appendChild(goldenStyle);

// Animated glowing gradient text for _main ._label
(function () {
  const el = document.querySelector('._main ._label');
  if (!el) return;

  el.style.backgroundImage = 'linear-gradient(90deg, white, #ffb300, white)';
  el.style.backgroundSize = '300% auto';
  el.style.color = 'transparent';
  el.style.backgroundClip = 'text';
  el.style.webkitBackgroundClip = 'text';
  el.style.fontWeight = 'bold';
  el.style.animation = 'shine 2s linear infinite, glow 1.5s ease-in-out infinite alternate';
  el.style.textShadow = `
    0 0 4px #ffd54f,
    0 0 8px #fbc02d,
    0 0 16px #ffb300,
    0 0 24px white
  `;
})();

// Apply to common components
const goldenSelectors = [
  '._top', '._bottom',
  '.main-v2f8c4', '.main-zf0xiu', '.main-1tz8zqw',
  '.main-hp9qcx', '.main-x9v4u5', '.in_container',
  '._clickable', '.Icon-arrow_up', '.fa-play'
];

function applyGoldenTheme(el) {
  if (el.classList.contains('_top') || el.classList.contains('_bottom')) {
    el.classList.add('animated-bar');
    el.style.color = '#ffe699';
    el.querySelectorAll('*').forEach(child => {
      child.style.color = '#ffe699';
      child.style.textShadow = '0 0 6px #ffca28';
    });
    return;
  }

  el.style.background = 'linear-gradient(135deg, #2b1b00, #3b2900)';
  el.style.color = '#ffe699';
  el.style.borderRadius = '1rem';
  el.style.textShadow = '0 0 6px #ffb300';

  if (el.classList.contains('Icon-arrow_up') || el.classList.contains('fa-play')) {
    el.classList.add('rounded-icon');
  }

  el.querySelectorAll('*').forEach(child => {
    child.style.color = '#ffe699';
    child.style.textShadow = '0 0 6px #ffb300';
  });
}

document.querySelectorAll(goldenSelectors.join(',')).forEach(applyGoldenTheme);

const goldenObserver = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType === 1) {
        if (goldenSelectors.some(sel => node.matches(sel))) {
          applyGoldenTheme(node);
        }
        node.querySelectorAll(goldenSelectors.join(',')).forEach(applyGoldenTheme);
      }
    }
  }
});
goldenObserver.observe(document.body, { childList: true, subtree: true });

// _active animation
const goldenStyledElements = new WeakMap();
setInterval(() => {
  document.querySelectorAll('._active').forEach(el => {
    if (!el.classList.contains('_active-gradient-animated')) {
      if (!goldenStyledElements.has(el)) {
        goldenStyledElements.set(el, {
          background: el.style.background,
          color: el.style.color,
          borderRadius: el.style.borderRadius,
        });
      }
      el.classList.add('_active-gradient-animated');
    }
  });
}, 300);

// 🟡 Hero Shine Effect – Golden Theme
function applyGoldenShiny(el) {
    if (!el.classList.contains('golden-shiny')) {
      el.classList.add('golden-shiny');
    }
  }
  
  const goldenTarget = document.querySelector('.main-y3ei6l');
  if (goldenTarget) applyGoldenShiny(goldenTarget);
  
  const goldenWatcher = new MutationObserver(() => {
    const el = document.querySelector('.main-y3ei6l');
    if (el) {
      applyGoldenShiny(el);
      goldenWatcher.disconnect();
    }
  });
  goldenWatcher.observe(document.body, { childList: true, subtree: true });
  

  
  
// _today styling
function styleTodayElement(el) {
  el.style.background = 'linear-gradient(135deg, #ffd700, #ffa500)';
  el.style.color = '#000';
  el.style.borderRadius = '1rem';
  el.style.boxShadow = '0 0 8px #ffcc00';
  el.style.fontWeight = 'bold';
}
document.querySelectorAll('._today').forEach(styleTodayElement);
const observerToday = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType === 1) {
        if (node.classList.contains('_today')) {
          styleTodayElement(node);
        }
        node.querySelectorAll('._today').forEach(styleTodayElement);
      }
    }
  }
});
observerToday.observe(document.body, { childList: true, subtree: true });










// Apply to existing elements
document.querySelectorAll('._fore').forEach(styleForeElement);

// Observe and style new elements dynamically
const observerFore = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType === 1) {
        if (node.classList.contains('_fore')) styleForeElement(node);
        node.querySelectorAll('._fore').forEach(styleForeElement);
      }
    }
  }
});
observerFore.observe(document.body, { childList: true, subtree: true });




// 🟡 GOLDEN STYLING FOR _day AND _note
function styleGoldenDay(el) {
  el.style.background = 'linear-gradient(135deg, #ffdd66, #ffaa00)';
  el.style.color = '#000';
  el.style.borderRadius = '1rem';
  el.style.boxShadow = '0 0 8px #ffcc33';
  el.style.fontWeight = 'bold';
}
function styleGoldenNote(el) {
  el.style.background = 'linear-gradient(135deg, #fff3cd, #ffe066)';
  el.style.color = '#2b1b00';
  el.style.borderRadius = '0.75rem';
  el.style.padding = '8px';
  el.style.boxShadow = '0 0 10px #ffd54f';
}
document.querySelectorAll('._day').forEach(styleGoldenDay);
document.querySelectorAll('._note').forEach(styleGoldenNote);
const observerGolden = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.classList.contains('_day')) styleGoldenDay(node);
      if (node.classList.contains('_note')) styleGoldenNote(node);
      node.querySelectorAll('._day').forEach(styleGoldenDay);
      node.querySelectorAll('._note').forEach(styleGoldenNote);
    }
  }
});
observerGolden.observe(document.body, { childList: true, subtree: true });

// Golden calendar icon
function styleGoldenCalendar(el) {
  el.style.color = '#ffcc33';
  el.style.textShadow = '0 0 6px #ffb300';
  el.style.background = 'none';
}
document.querySelectorAll('.fa-calendar-alt').forEach(styleGoldenCalendar);
const calendarObserverGolden = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.classList.contains('fa-calendar-alt')) {
        styleGoldenCalendar(node);
      }
      node.querySelectorAll('.fa-calendar-alt').forEach(styleGoldenCalendar);
    }
  }
});
calendarObserverGolden.observe(document.body, { childList: true, subtree: true });

// Golden style for .fa-calendar-star
const style = document.createElement('style');
style.textContent = `
  .fa-calendar-star,
  .fa-calendar-star::before {
    color: #FFD700 !important;
  }
`;
document.head.appendChild(style);
const observer = new MutationObserver(mutations => {
  mutations.forEach(mutation => {
    mutation.addedNodes.forEach(node => {
      if (node.nodeType === 1) {
        if (node.classList?.contains('fa-calendar-star')) {
          node.style.color = '#FFD700';
        } else {
          node.querySelectorAll?.('.fa-calendar-star')?.forEach(el => {
            el.style.color = '#FFD700';
          });
        }
      }
    });
  });
});
observer.observe(document.body, {
  childList: true,
  subtree: true
});



// 🟡 Only change text color of _dots elements to golden
function styleGoldenDots(el) {
  el.style.color = '#ffcc33';
  el.style.textShadow = '0 0 4px #ffb300';
}

// Apply to existing ._dots elements
document.querySelectorAll('._dots').forEach(styleGoldenDots);

// Observe for future ._dots elements
const observerDots = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;

      if (node.classList.contains('_dots')) styleGoldenDots(node);
      node.querySelectorAll('._dots').forEach(styleGoldenDots);
    }
  }
});
observerDots.observe(document.body, { childList: true, subtree: true });



// 7/15/2025
document.querySelectorAll('._fore').forEach(el => {
  el.style.setProperty('background', 'linear-gradient(135deg, #b87f00, #7a5400)', 'important');
  el.style.setProperty('padding', '12px', 'important');
  el.style.setProperty('border-radius', '1rem', 'important');
  el.style.setProperty('box-shadow', '0 0 10px #b87f00', 'important');

  el.querySelectorAll('*').forEach(child => {
    child.style.setProperty('background', 'transparent', 'important');
  });
});



// same day 

// 🟡 Combined Golden Theme Enhancements

// 🟡 Font Awesome Icons to Gold
function styleAllFontAwesome(el) {
  el.style.setProperty('color', '#ffcc33', 'important');
  el.style.setProperty('textShadow', '0 0 6px #ffb300', 'important');
}
document.querySelectorAll('.fa, .fas, .far, .fal, .fab').forEach(styleAllFontAwesome);
const observerFA = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.classList?.toString().match(/\bfa[bsrl]?\b/)) {
        styleAllFontAwesome(node);
      }
      node.querySelectorAll?.('.fa, .fas, .far, .fal, .fab')?.forEach(styleAllFontAwesome);
    }
  }
});
observerFA.observe(document.body, { childList: true, subtree: true });

// 🟡 Golden Background for .main-1k6w26b
const styleMain = document.createElement('style');
styleMain.innerHTML = `
  .main-1k6w26b {
    background: linear-gradient(135deg, #3b2900, #2b1b00) !important;
    color: #ffcc33 !important;
    border: 2px solid #6b4e00 !important;
    border-radius: 0.75rem !important;
    box-shadow: 0 0 10px #ffb300 !important;
    padding: 12px !important;
    transition: border 0.3s ease, box-shadow 0.3s ease;
  }
  .main-1k6w26b:hover {
    border: 2px solid #ffcc33 !important;
    box-shadow: 0 0 14px #ffcc33 !important;
  }
`;
document.head.appendChild(styleMain);
function styleGoldenMainBlock(el) {
  el.classList.add('main-1k6w26b');
}
document.querySelectorAll('.main-1k6w26b').forEach(styleGoldenMainBlock);
const observerGoldenMainBlock = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.classList?.contains('main-1k6w26b')) {
        styleGoldenMainBlock(node);
      }
      node.querySelectorAll?.('.main-1k6w26b')?.forEach(styleGoldenMainBlock);
    }
  }
});
observerGoldenMainBlock.observe(document.body, { childList: true, subtree: true });


// 🟡 Golden Border Shades for .main-uv8k3y

// Inject CSS styles
const styleUv = document.createElement('style');
styleUv.innerHTML = `
  .main-uv8k3y {
    border: 2px solid #806000 !important; /* darker golden base */
    transition: border 0.3s ease, box-shadow 0.3s ease;
    border-radius: 0.75rem !important;
  }
  .main-uv8k3y:hover {
    border: 2px solid #ffcc33 !important; /* bright gold */
    box-shadow: 0 0 10px #ffcc33 !important;
  }
`;
document.head.appendChild(styleUv);

// Apply to existing elements
document.querySelectorAll('.main-uv8k3y').forEach(el => {
  el.classList.add('main-uv8k3y');
});

// Observe and apply to new elements
const observerUv = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;

      if (node.classList?.contains('main-uv8k3y')) {
        node.classList.add('main-uv8k3y');
      }

      node.querySelectorAll?.('.main-uv8k3y')?.forEach(el => {
        el.classList.add('main-uv8k3y');
      });
    }
  }
});
observerUv.observe(document.body, { childList: true, subtree: true });

// 🟡 Make all elements inside ._fore have transparent background
// 🟡 EXCEPT Font Awesome elements — they get dark gold background

function applyForeInnerStyle(el) {
  const darkGold = '#3b2900';

  el.querySelectorAll('*').forEach(child => {
    const isFontAwesome =
      [...child.classList].some(cls =>
        cls.startsWith('fa') || ['fas', 'far', 'fal', 'fab'].includes(cls)
      );

    if (isFontAwesome) {
      child.style.setProperty('background', darkGold, 'important');
      child.style.setProperty('color', '#ffcc33', 'important');
      child.style.setProperty('borderRadius', '0.5rem', 'important');
      child.style.setProperty('padding', '6px', 'important');
      child.style.setProperty('textShadow', '0 0 6px #ffb300', 'important');
    } else {
      child.style.setProperty('background', 'transparent', 'important');
    }
  });
}

// 🟡 Apply to all existing _fore elements
document.querySelectorAll('._fore').forEach(applyForeInnerStyle);

// 🟡 Observe future _fore elements and their children
const observerForeInner = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;

      if (node.classList.contains('_fore')) applyForeInnerStyle(node);

      node.querySelectorAll?.('._fore')?.forEach(applyForeInnerStyle);
    }
  }
});
observerForeInner.observe(document.body, { childList: true, subtree: true });


// 🟡 Style ._fore with dark gold and children transparent

function styleForeElement(el) {
  const darkGold = '#4b3a0a';

  el.style.setProperty('background', darkGold, 'important');
  el.style.setProperty('padding', '12px', 'important');
  el.style.setProperty('border-radius', '1rem', 'important');
  el.style.setProperty('box-shadow', `0 0 8px ${darkGold}`, 'important');

  el.querySelectorAll('*').forEach(child => {
    child.style.setProperty('background', 'transparent', 'important');
  });
}




// 🟡 Apply to existing ._fore
document.querySelectorAll('._fore').forEach(styleForeElement);

// 🟡 Observe and apply to new ._fore elements
const observerStrictFore = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;

      if (node.classList?.contains('_fore')) {
        styleForeElement(node);
      }

      node.querySelectorAll?.('._fore')?.forEach(styleForeElement);
    }
  }
});
observerStrictFore.observe(document.body, { childList: true, subtree: true });


// 🟡 Dark Golden Style for .container-children
function styleDarkGoldenContainer(el) {
  el.style.setProperty('background', 'linear-gradient(135deg, #4b3a0a, #b8860b)', 'important');
  el.style.setProperty('color', '#fff8dc', 'important');
  el.style.setProperty('border-radius', '1rem', 'important');
  el.style.setProperty('padding', '12px', 'important');
  el.style.setProperty('box-shadow', '0 0 10px #8b6508', 'important');
}

// Apply to existing elements
document.querySelectorAll('.container-children').forEach(styleDarkGoldenContainer);

// Observe and apply to future elements
const observerContainerChildren = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;
      if (node.classList?.contains('container-children')) {
        styleDarkGoldenContainer(node);
      }
      node.querySelectorAll?.('.container-children')?.forEach(styleDarkGoldenContainer);
    }
  }
});
observerContainerChildren.observe(document.body, { childList: true, subtree: true });






// 🟡 Style function for .widget-title
function styleWidgetTitle(el) {
  el.style.setProperty('background', '#3b2900', 'important'); // dark gold bg
  el.style.setProperty('color', '#ffcc33', 'important');      // bright gold text
  el.style.setProperty('text-shadow', '0 0 6px #ffb300', 'important');
  el.style.setProperty('padding', '6px 12px', 'important');
  el.style.setProperty('border-radius', '0.5rem', 'important');
}

// 🟡 Apply to existing .widget-title elements
document.querySelectorAll('.widget-title').forEach(styleWidgetTitle);

// 🟡 Observe future .widget-title elements
const observerWidgetTitle = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (node.nodeType !== 1) continue;

      if (node.classList.contains('widget-title')) {
        styleWidgetTitle(node);
      }

      node.querySelectorAll?.('.widget-title')?.forEach(styleWidgetTitle);
    }
  }
});
observerWidgetTitle.observe(document.body, { childList: true, subtree: true });





// Use a unique observer name to avoid conflicts
const observer_css1h088zk_gold = new MutationObserver(() => {
  document.querySelectorAll('.css-1h088zk').forEach(el => {
    el.style.cssText += `
      background-color: #d4af37 !important;  /* Gold background */
      color: #fff8dc !important;             /* Light text for contrast */
      border-radius: 8px !important;
      transition: all 0.3s ease !important;
      box-shadow: 0 0 10px #b8860b !important; /* Subtle gold glow */
    `;
    console.log('Gold style applied:', el);
  });
});

// Apply immediately in case the element already exists
document.querySelectorAll('.css-1h088zk').forEach(el => {
  el.style.cssText += `
    background-color: #d4af37 !important;
    color: #fff8dc !important;
    border-radius: 8px !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 0 10px #b8860b !important;
  `;
  console.log('Gold style applied:', el);
});

// Observe for future elements
observer_css1h088zk_gold.observe(document.body, {
  childList: true,
  subtree: true,
});






// Gold colors
const mainGold = '#d4af37';     // For the main element
const beforeGold = '#f0d264';   // Slightly lighter gold for ::before

// Add style for ::before only (color only, no position/layout changes)
const pseudoStyle = document.createElement('style');
pseudoStyle.textContent = `
  ._unit_name::before {
    background-color: ${beforeGold} !important;
  }
`;
document.head.appendChild(pseudoStyle);

// Function to style all _unit_name elements
const styleUnitNameGold = () => {
  document.querySelectorAll('._unit_name').forEach(el => {
    el.style.backgroundColor = mainGold;
    el.style.color = '#fff8dc';
    el.style.borderRadius = '6px';
    el.style.padding = '4px';
    el.style.transition = 'all 0.3s ease';
    // no position/overflow set here
  });
};

// Apply to existing elements
styleUnitNameGold();

// Watch for new _unit_name elements
const observer_unit_name_gold = new MutationObserver(() => {
  styleUnitNameGold();
});
observer_unit_name_gold.observe(document.body, {
  childList: true,
  subtree: true
});


// Gold styling (color only)
const applyGoldToMain = () => {
  document.querySelectorAll('.main-18ys6ck').forEach(el => {
    el.style.backgroundColor = '#d4af37'; // Moderate gold
    el.style.color = '#fff8dc';           // Light text for contrast
    el.style.transition = 'all 0.3s ease';
  });
};

// Run initially
applyGoldToMain();

// Watch for new elements
const observer_main_gold = new MutationObserver(() => {
  applyGoldToMain();
});
observer_main_gold.observe(document.body, {
  childList: true,
  subtree: true
});




// Hover border color (gold)
const hoverBorderGold = '#d4af37'; // Gold on hover

// Inject CSS for both classes
const hoverStyle = document.createElement('style');
hoverStyle.textContent = `
  .padding:hover,
  .main-5u5jqx:hover {
    border: 2px solid ${hoverBorderGold} !important;
    transition: border-color 0.3s ease !important;
  }
`;
document.head.appendChild(hoverStyle);

// Function to ensure classes are applied (even dynamically)
const applyHoverClasses = () => {
  document.querySelectorAll('.padding, .main-5u5jqx').forEach(el => {
    // Just ensures the class is not stripped; styling is handled via CSS
    el.classList.add(...el.classList);
  });
};
applyHoverClasses();

// Observe DOM for new elements
const observer_hover_gold = new MutationObserver(() => {
  applyHoverClasses();
});
observer_hover_gold.observe(document.body, {
  childList: true,
  subtree: true
});



// Define CSS with gradient and animation
const styleXzur6n = document.createElement('style');
styleXzur6n.textContent = `
  @keyframes goldGradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
  }

  .css-xzur6n {
    background: linear-gradient(270deg, #d4af37, #f0d264, #c9a000);
    background-size: 600% 600%;
    animation: goldGradientMove 6s ease infinite;
    color: #fff8dc !important;
    transition: all 0.3s ease;
    border-radius: 6px;
  }
`;
document.head.appendChild(styleXzur6n);

// Apply class styles if already present
const applyGoldGradient = () => {
  document.querySelectorAll('.css-xzur6n').forEach(el => {
    el.classList.add('css-xzur6n'); // No-op but ensures consistency
  });
};

applyGoldGradient(); // Immediate

// Observer to handle dynamically added elements
const observer_xzur6n = new MutationObserver(() => {
  applyGoldGradient();
});
observer_xzur6n.observe(document.body, {
  childList: true,
  subtree: true
});




console.log("🟡 Golden theme script injected");




