  const applyRedHeaderStyle = (header) => {
    header.style.background = 'linear-gradient(135deg, #8b0000, #b22222)'; // darker red tones
    header.style.color = '#fff0f0'; // light text for contrast
    header.style.boxShadow = '0 0 10px #ff0000'; // soft red glow
    header.style.transition = 'all 0.3s ease';
  };

  // Check if header already exists
  const existingHeader = document.querySelector('header');
  if (existingHeader) {
    applyRedHeaderStyle(existingHeader);
  } else {
    // Wait for it if not there
    const observer = new MutationObserver((mutations, obs) => {
      const header = document.querySelector('header');
      if (header) {
        applyRedHeaderStyle(header);
        obs.disconnect();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  // Base Background
  document.body.style.background = '#1b0000';
  document.body.style.color = '#ff9999';

  // Universal Link Styling
  const redStyle = document.createElement('style');
  redStyle.innerHTML = `
    a {
      color: #ff3333 !important;
      text-shadow: 0 0 4px #ff0000, 0 0 8px #cc0000;
      transition: 0.3s;
    }
    a:hover {
      color: #ffffff !important;
    }
    h1, h2, h3, h4, h5, h6 {
      color: #ff4d4d !important;
      text-shadow: 0 0 6px #ff0000, 0 0 12px #cc0000;
    }
    p {
      color: #ff9999 !important;
    }
    button, .Button {
      background: linear-gradient(90deg, #ff0000, #ff6666);
      color: black;
      padding: 8px 16px;
      border: none;
      border-radius: 2rem;
      box-shadow: 0 0 10px #ff3333;
      cursor: pointer;
      font-weight: bold;
      transition: 0.3s;
    }
    button:hover, .Button:hover {
      box-shadow: 0 0 20px #ff9999;
    }

    @keyframes darkGradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    ._active-gradient-animated {
      background: linear-gradient(270deg, #ff0000, #1b0000);
      background-size: 400% 400%;
      animation: darkGradientShift 5s ease infinite;
      color: white !important;
      border-radius: 1rem !important;
    }

    @keyframes redGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    @keyframes thinShineSweep {
      0% { left: -50%; top: -50%; }
      100% { left: 150%; top: 150%; }
    }

    .red-shiny {
      background: linear-gradient(270deg, #ff0000, #1b0000, #ff0000);
      background-size: 400% 400%;
      animation: redGradientMove 6s ease-in-out infinite;
      color: white !important;
      border-radius: 1rem !important;
      position: relative;
      overflow: hidden;
      z-index: 0;
    }

    .red-shiny::after {
      content: '';
      position: absolute;
      width: 150%;
      height: 2px;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
      animation: thinShineSweep 2.5s linear infinite;
      transform: rotate(45deg);
      pointer-events: none;
      z-index: 1;
    }

    .rounded-icon {
      background: linear-gradient(135deg, #1b0000, #290000);
      border-radius: 50%;
      padding: 10px;
      color: #ff3333;
      text-shadow: 0 0 6px #ff0000;
      transition: 0.3s;
    }

    .rounded-icon:hover {
      color: #ffffff;
      text-shadow: 0 0 10px #ff9999;
    }

    .animated-bar {
      background: linear-gradient(270deg, #ff0000, #290000);
      background-size: 300% 300%;
      animation: darkGradientShift 6s ease-in-out infinite;
    }

    .Icon-arrow_up {
      background: linear-gradient(135deg, #1b0000, #290000);
      border-radius: 50%;
      padding: 10px;
      color: #ff3333;
      text-shadow: 0 0 6px #ff0000;
      transition: 0.3s;
    }

    .Icon-arrow_up:hover {
      color: #ffffff;
      text-shadow: 0 0 10px #ff9999;
    }
  `;
  document.head.appendChild(redStyle);

  // Animated glowing gradient text for _main ._label
  (function () {
    const el = document.querySelector('._main ._label');
    if (!el) return;

    el.style.backgroundImage = 'linear-gradient(90deg, white, #ff0000, white)';
    el.style.backgroundSize = '300% auto';
    el.style.color = 'transparent';
    el.style.backgroundClip = 'text';
    el.style.webkitBackgroundClip = 'text';
    el.style.fontWeight = 'bold';
    el.style.animation = 'shine 2s linear infinite, glow 1.5s ease-in-out infinite alternate';
    el.style.textShadow = `
      0 0 4px #ff4d4d,
      0 0 8px #ff3333,
      0 0 16px #ff0000,
      0 0 24px white
    `;
  })();

  // Apply to common components
  const redSelectors = [
    '._top', '._bottom',
    '.main-v2f8c4', '.main-zf0xiu', '.main-1tz8zqw',
    '.main-hp9qcx', '.main-x9v4u5', '.in_container',
    '._clickable', '.Icon-arrow_up', '.fa-play'
  ];

  function applyRedTheme(el) {
    if (el.classList.contains('_top') || el.classList.contains('_bottom')) {
      el.classList.add('animated-bar');
      el.style.color = '#ff9999';
      el.querySelectorAll('*').forEach(child => {
        child.style.color = '#ff9999';
        child.style.textShadow = '0 0 6px #ff3333';
      });
      return;
    }

    el.style.background = 'linear-gradient(135deg, #1b0000, #290000)';
    el.style.color = '#ff9999';
    el.style.borderRadius = '1rem';
    el.style.textShadow = '0 0 6px #ff0000';

    if (el.classList.contains('Icon-arrow_up') || el.classList.contains('fa-play')) {
      el.classList.add('rounded-icon');
    }

    el.querySelectorAll('*').forEach(child => {
      child.style.color = '#ff9999';
      child.style.textShadow = '0 0 6px #ff0000';
    });
  }

  document.querySelectorAll(redSelectors.join(',')).forEach(applyRedTheme);

  const redObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (redSelectors.some(sel => node.matches(sel))) {
            applyRedTheme(node);
          }
          node.querySelectorAll(redSelectors.join(',')).forEach(applyRedTheme);
        }
      }
    }
  });
  redObserver.observe(document.body, { childList: true, subtree: true });

  // _active animation
  const redStyledElements = new WeakMap();
  setInterval(() => {
    document.querySelectorAll('._active').forEach(el => {
      if (!el.classList.contains('_active-gradient-animated')) {
        if (!redStyledElements.has(el)) {
          redStyledElements.set(el, {
            background: el.style.background,
            color: el.style.color,
            borderRadius: el.style.borderRadius,
          });
        }
        el.classList.add('_active-gradient-animated');
      }
    });
  }, 300);


  // 🔴 Hero Shine Effect – Red Theme
  function applyRedShiny(el) {
    if (!el.classList.contains('red-shiny')) {
      el.classList.add('red-shiny');
    }
  }

  const redTarget = document.querySelector('.main-y3ei6l');
  if (redTarget) applyRedShiny(redTarget);

  const redWatcher = new MutationObserver(() => {
    const el = document.querySelector('.main-y3ei6l');
    if (el) {
      applyRedShiny(el);
      redWatcher.disconnect();
    }
  });
  redWatcher.observe(document.body, { childList: true, subtree: true });




  // _today styling
  function styleTodayElement(el) {
    el.style.background = 'linear-gradient(135deg, #ff3333, #cc0000)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #ff0000';
    el.style.fontWeight = 'bold';
  }
  document.querySelectorAll('._today').forEach(styleTodayElement);
  const observerToday = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_today')) {
            styleTodayElement(node);
          }
          node.querySelectorAll('._today').forEach(styleTodayElement);
        }
      }
    }
  });
  observerToday.observe(document.body, { childList: true, subtree: true });

  // Apply to existing elements
  document.querySelectorAll('._fore').forEach(styleForeElement);

  // Observe and style new elements dynamically
  const observerFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_fore')) styleForeElement(node);
          node.querySelectorAll('._fore').forEach(styleForeElement);
        }
      }
    }
  });
  observerFore.observe(document.body, { childList: true, subtree: true });

  // 🟡 RED STYLING FOR _day AND _note
  function styleRedDay(el) {
    el.style.background = 'linear-gradient(135deg, #ff6666, #cc0000)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #ff3333';
    el.style.fontWeight = 'bold';
  }
  function styleRedNote(el) {
    el.style.background = 'linear-gradient(135deg, #ffcccc, #ff6666)';
    el.style.color = '#1b0000';
    el.style.borderRadius = '0.75rem';
    el.style.padding = '8px';
    el.style.boxShadow = '0 0 10px #ff4d4d';
  }
  document.querySelectorAll('._day').forEach(styleRedDay);
  document.querySelectorAll('._note').forEach(styleRedNote);
  const observerRed = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('_day')) styleRedDay(node);
        if (node.classList.contains('_note')) styleRedNote(node);
        node.querySelectorAll('._day').forEach(styleRedDay);
        node.querySelectorAll('._note').forEach(styleRedNote);
      }
    }
  });
  observerRed.observe(document.body, { childList: true, subtree: true });

  // Red calendar icon
  function styleRedCalendar(el) {
    el.style.color = '#ff3333';
    el.style.textShadow = '0 0 6px #ff0000';
    el.style.background = 'none';
  }
  document.querySelectorAll('.fa-calendar-alt').forEach(styleRedCalendar);
  const calendarObserverRed = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('fa-calendar-alt')) {
          styleRedCalendar(node);
        }
        node.querySelectorAll('.fa-calendar-alt').forEach(styleRedCalendar);
      }
    }
  });
  calendarObserverRed.observe(document.body, { childList: true, subtree: true });

  // Red style for .fa-calendar-star
  const style = document.createElement('style');
  style.textContent = `
    .fa-calendar-star,
    .fa-calendar-star::before {
      color: #ff3333 !important;
    }
  `;
  document.head.appendChild(style);
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.classList?.contains('fa-calendar-star')) {
            node.style.color = '#ff3333';
          } else {
            node.querySelectorAll?.('.fa-calendar-star')?.forEach(el => {
              el.style.color = '#ff3333';
            });
          }
        }
      });
    });
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // 🟡 Only change text color of _dots elements to red
  function styleRedDots(el) {
    el.style.color = '#ff3333';
    el.style.textShadow = '0 0 4px #ff0000';
  }

  // Apply to existing ._dots elements
  document.querySelectorAll('._dots').forEach(styleRedDots);

  // Observe for future ._dots elements
  const observerDots = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;

        if (node.classList.contains('_dots')) styleRedDots(node);
        node.querySelectorAll('._dots').forEach(styleRedDots);
      }
    }
  });
  observerDots.observe(document.body, { childList: true, subtree: true });

  // 7/15/2025
  document.querySelectorAll('._fore').forEach(el => {
    el.style.setProperty('background', 'linear-gradient(135deg, #800000, #4d0000)', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #800000', 'important');

    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  });

  // 🟡 Combined Red Theme Enhancements

  // 🟡 Font Awesome Icons to Red
  function styleAllFontAwesome(el) {
    el.style.setProperty('color', '#ff3333', 'important');
    el.style.setProperty('textShadow', '0 0 6px #ff0000', 'important');
  }
  document.querySelectorAll('.fa, .fas, .far, .fal, .fab').forEach(styleAllFontAwesome);
  const observerFA = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.toString().match(/\bfa[bsrl]?\b/)) {
          styleAllFontAwesome(node);
        }
        node.querySelectorAll?.('.fa, .fas, .far, .fal, .fab')?.forEach(styleAllFontAwesome);
      }
    }
  });
  observerFA.observe(document.body, { childList: true, subtree: true });

  // 🟡 Red Background for .main-1k6w26b
  const styleMain = document.createElement('style');
  styleMain.innerHTML = `
    .main-1k6w26b {
      background: linear-gradient(135deg, #290000, #1b0000) !important;
      color: #ff3333 !important;
      border: 2px solid #660000 !important;
      border-radius: 0.75rem !important;
      box-shadow: 0 0 10px #ff0000 !important;
      padding: 12px !important;
      transition: border 0.3s ease, box-shadow 0.3s ease;
    }
    .main-1k6w26b:hover {
      border: 2px solid #ff3333 !important;
      box-shadow: 0 0 14px #ff3333 !important;
    }
  `;
  document.head.appendChild(styleMain);
  function styleRedMainBlock(el) {
    el.classList.add('main-1k6w26b');
  }
  document.querySelectorAll('.main-1k6w26b').forEach(styleRedMainBlock);
  const observerRedMainBlock = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('main-1k6w26b')) {
          styleRedMainBlock(node);
        }
        node.querySelectorAll?.('.main-1k6w26b')?.forEach(styleRedMainBlock);
      }
    }
  });
  observerRedMainBlock.observe(document.body, { childList: true, subtree: true });

  // 🟡 Red Border Shades for .main-uv8k3y
  const styleUv = document.createElement('style');
  styleUv.innerHTML = `
    .main-uv8k3y {
      border: 2px solid #660000 !important; /* darker red base */
      transition: border 0.3s ease, box-shadow 0.3s ease;
      border-radius: 0.75rem !important;
    }
    .main-uv8k3y:hover {
      border: 2px solid #ff3333 !important; /* bright red */
      box-shadow: 0 0 10px #ff3333 !important;
    }
  `;
  document.head.appendChild(styleUv);

  // Apply to existing elements
  document.querySelectorAll('.main-uv8k3y').forEach(el => {
    el.classList.add('main-uv8k3y');
  });

  // Observe and apply to new elements
  const observerUv = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;

        if (node.classList?.contains('main-uv8k3y')) {
          node.classList.add('main-uv8k3y');
        }

        node.querySelectorAll?.('.main-uv8k3y')?.forEach(el => {
          el.classList.add('main-uv8k3y');
        });
      }
    }
  });
  observerUv.observe(document.body, { childList: true, subtree: true });

  // 🟡 Make all elements inside ._fore have transparent background
  // 🟡 EXCEPT Font Awesome elements — they get dark red background
  function applyForeInnerStyle(el) {
    const darkRed = '#290000';

    el.querySelectorAll('*').forEach(child => {
      const isFontAwesome =
        [...child.classList].some(cls =>
          cls.startsWith('fa') || ['fas', 'far', 'fal', 'fab'].includes(cls)
        );

      if (isFontAwesome) {
        child.style.setProperty('background', darkRed, 'important');
        child.style.setProperty('color', '#ff3333', 'important');
        child.style.setProperty('borderRadius', '0.5rem', 'important');
        child.style.setProperty('padding', '6px', 'important');
        child.style.setProperty('textShadow', '0 0 6px #ff0000', 'important');
      } else {
        child.style.setProperty('background', 'transparent', 'important');
      }
    });
  }

  // 🟡 Apply to all existing _fore elements
  document.querySelectorAll('._fore').forEach(applyForeInnerStyle);

  // 🟡 Observe future _fore elements and their children
  const observerForeInner = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;

        if (node.classList.contains('_fore')) applyForeInnerStyle(node);

        node.querySelectorAll?.('._fore')?.forEach(applyForeInnerStyle);
      }
    }
  });
  observerForeInner.observe(document.body, { childList: true, subtree: true });

  // 🟡 Style ._fore with dark red and children transparent
  function styleForeElement(el) {
    const darkRed = '#4b0a0a';

    el.style.setProperty('background', darkRed, 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', `0 0 8px ${darkRed}`, 'important');

    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  }

  // 🟡 Apply to existing ._fore
  document.querySelectorAll('._fore').forEach(styleForeElement);

  // 🟡 Observe and apply to new ._fore elements
  const observerStrictFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;

        if (node.classList?.contains('_fore')) {
          styleForeElement(node);
        }

        node.querySelectorAll?.('._fore')?.forEach(styleForeElement);
      }
    }
  });
  observerStrictFore.observe(document.body, { childList: true, subtree: true });

  // 🟡 Dark Red Style for .container-children
  function styleDarkRedContainer(el) {
    el.style.setProperty('background', 'linear-gradient(135deg, #4b0a0a, #b80000)', 'important');
    el.style.setProperty('color', '#fff0f0', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #8b0000', 'important');
  }

  // Apply to existing elements
  document.querySelectorAll('.container-children').forEach(styleDarkRedContainer);

  // Observe and apply to future elements
  const observerContainerChildren = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('container-children')) {
          styleDarkRedContainer(node);
        }
        node.querySelectorAll?.('.container-children')?.forEach(styleDarkRedContainer);
      }
    }
  });
  observerContainerChildren.observe(document.body, { childList: true, subtree: true });

  // 🟡 Style function for .widget-title
  function styleWidgetTitle(el) {
    el.style.setProperty('background', '#290000', 'important'); // dark red bg
    el.style.setProperty('color', '#ff3333', 'important');      // bright red text
    el.style.setProperty('text-shadow', '0 0 6px #ff0000', 'important');
    el.style.setProperty('padding', '6px 12px', 'important');
    el.style.setProperty('border-radius', '0.5rem', 'important');
  }

  // 🟡 Apply to existing .widget-title elements
  document.querySelectorAll('.widget-title').forEach(styleWidgetTitle);

  // 🟡 Observe future .widget-title elements
  const observerWidgetTitle = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;

        if (node.classList.contains('widget-title')) {
          styleWidgetTitle(node);
        }

        node.querySelectorAll?.('.widget-title')?.forEach(styleWidgetTitle);
      }
    }
  });
  observerWidgetTitle.observe(document.body, { childList: true, subtree: true });

  // Use a unique observer name to avoid conflicts
  const observer_css1h088zk_red = new MutationObserver(() => {
    document.querySelectorAll('.css-1h088zk').forEach(el => {
      el.style.cssText += `
        background-color: #b80000 !important;  /* Red background */
        color: #fff0f0 !important;             /* Light text for contrast */
        border-radius: 8px !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 0 10px #8b0000 !important; /* Subtle red glow */
      `;
      console.log('Red style applied:', el);
    });
  });

  // Apply immediately in case the element already exists
  document.querySelectorAll('.css-1h088zk').forEach(el => {
    el.style.cssText += `
      background-color: #b80000 !important;
      color: #fff0f0 !important;
      border-radius: 8px !important;
      transition: all 0.3s ease !important;
      box-shadow: 0 0 10px #8b0000 !important;
    `;
    console.log('Red style applied:', el);
  });

  // Observe for future elements
  observer_css1h088zk_red.observe(document.body, {
    childList: true,
    subtree: true,
  });

  // Red colors
  const mainRed = '#b80000';     // For the main element
  const beforeRed = '#ff6666';   // Slightly lighter red for ::before

  // Add style for ::before only (color only, no position/layout changes)
  const pseudoStyle = document.createElement('style');
  pseudoStyle.textContent = `
    ._unit_name::before {
      background-color: ${beforeRed} !important;
    }
  `;
  document.head.appendChild(pseudoStyle);

  // Function to style all _unit_name elements
  const styleUnitNameRed = () => {
    document.querySelectorAll('._unit_name').forEach(el => {
      el.style.backgroundColor = mainRed;
      el.style.color = '#fff0f0';
      el.style.borderRadius = '6px';
      el.style.padding = '4px';
      el.style.transition = 'all 0.3s ease';
    });
  };

  // Apply to existing elements
  styleUnitNameRed();

  // Watch for new _unit_name elements
  const observer_unit_name_red = new MutationObserver(() => {
    styleUnitNameRed();
  });
  observer_unit_name_red.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Red styling (color only)
  const applyRedToMain = () => {
    document.querySelectorAll('.main-18ys6ck').forEach(el => {
      el.style.backgroundColor = '#b80000'; // Moderate red
      el.style.color = '#fff0f0';           // Light text for contrast
      el.style.transition = 'all 0.3s ease';
    });
  };

  // Run initially
  applyRedToMain();

  // Watch for new elements
  const observer_main_red = new MutationObserver(() => {
    applyRedToMain();
  });
  observer_main_red.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Hover border color (red)
  const hoverBorderRed = '#b80000'; // Red on hover

  // Inject CSS for both classes
  const hoverStyle = document.createElement('style');
  hoverStyle.textContent = `
    .padding:hover,
    .main-5u5jqx:hover {
      border: 2px solid ${hoverBorderRed} !important;
      transition: border-color 0.3s ease !important;
    }
  `;
  document.head.appendChild(hoverStyle);

  // Function to ensure classes are applied (even dynamically)
  const applyHoverClasses = () => {
    document.querySelectorAll('.padding, .main-5u5jqx').forEach(el => {
      // Just ensures the class is not stripped; styling is handled via CSS
      el.classList.add(...el.classList);
    });
  };
  applyHoverClasses();

  // Observe DOM for new elements
  const observer_hover_red = new MutationObserver(() => {
    applyHoverClasses();
  });
  observer_hover_red.observe(document.body, {
    childList: true,
    subtree: true
  });

  // Define CSS with gradient and animation
  const styleXzur6n = document.createElement('style');
  styleXzur6n.textContent = `
    @keyframes redGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .css-xzur6n {
      background: linear-gradient(270deg, #b80000, #ff6666, #990000);
      background-size: 600% 600%;
      animation: redGradientMove 6s ease infinite;
      color: #fff0f0 !important;
      transition: all 0.3s ease;
      border-radius: 6px;
    }
  `;
  document.head.appendChild(styleXzur6n);

  // Apply class styles if already present
  const applyRedGradient = () => {
    document.querySelectorAll('.css-xzur6n').forEach(el => {
      el.classList.add('css-xzur6n'); // No-op but ensures consistency
    });
  };

  applyRedGradient(); // Immediate

  // Observer to handle dynamically added elements
  const observer_xzur6n = new MutationObserver(() => {
    applyRedGradient();
  });
  observer_xzur6n.observe(document.body, {
    childList: true,
    subtree: true
  });

  console.log("🔴 Red theme script injected");