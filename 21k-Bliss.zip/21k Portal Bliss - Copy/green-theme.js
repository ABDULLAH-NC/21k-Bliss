const applyGreenHeaderStyle = (header) => {
    header.style.background = 'linear-gradient(135deg, #2e8b57, #3cb371)'; // darker green tones
    header.style.color = '#f0fff0'; // light text for contrast
    header.style.boxShadow = '0 0 10px #2e8b57'; // soft green glow
    header.style.transition = 'all 0.3s ease';
  };
  
  // Check if header already exists
  const existingHeader = document.querySelector('header');
  if (existingHeader) {
    applyGreenHeaderStyle(existingHeader);
  } else {
    // Wait for it if not there
    const observer = new MutationObserver((mutations, obs) => {
      const header = document.querySelector('header');
      if (header) {
        applyGreenHeaderStyle(header);
        obs.disconnect();
      }
    });
  
    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }
  
  // Base Background
  document.body.style.background = '#1b2b1b';
  document.body.style.color = '#99e699';
  
  // Universal Link Styling
  const greenStyle = document.createElement('style');
  greenStyle.innerHTML = `
    a {
      color: #33cc33 !important;
      text-shadow: 0 0 4px #00b300, 0 0 8px #008f00;
      transition: 0.3s;
    }
    a:hover {
      color: #ffffff !important;
    }
    h1, h2, h3, h4, h5, h6 {
      color: #4dff4d !important;
      text-shadow: 0 0 6px #00b300, 0 0 12px #009800;
    }
    p {
      color: #99e699 !important;
    }
    button, .Button {
      background: linear-gradient(90deg, #00b300, #40d740);
      color: black;
      padding: 8px 16px;
      border: none;
      border-radius: 2rem;
      box-shadow: 0 0 10px #28ca28;
      cursor: pointer;
      font-weight: bold;
      transition: 0.3s;
    }
    button:hover, .Button:hover {
      box-shadow: 0 0 20px #82e082;
    }
  
    @keyframes darkGradientShift {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    ._active-gradient-animated {
      background: linear-gradient(270deg, #00b300, #1b2b1b);
      background-size: 400% 400%;
      animation: darkGradientShift 5s ease infinite;
      color: white !important;
      border-radius: 1rem !important;
    }
  
    @keyframes greenGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    @keyframes thinShineSweep {
      0% { left: -50%; top: -50%; }
      100% { left: 150%; top: 150%; }
    }
  
    .green-shiny {
      background: linear-gradient(270deg, #00b300, #1b2b1b, #00b300);
      background-size: 400% 400%;
      animation: greenGradientMove 6s ease-in-out infinite;
      color: white !important;
      border-radius: 1rem !important;
      position: relative;
      overflow: hidden;
      z-index: 0;
    }
  
    .green-shiny::after {
      content: '';
      position: absolute;
      width: 150%;
      height: 2px;
      background: linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent);
      animation: thinShineSweep 2.5s linear infinite;
      transform: rotate(45deg);
      pointer-events: none;
      z-index: 1;
    }
  
    .rounded-icon {
      background: linear-gradient(135deg, #1b2b1b, #1b3b1b);
      border-radius: 50%;
      padding: 10px;
      color: #33cc33;
      text-shadow: 0 0 6px #00b300;
      transition: 0.3s;
    }
  
    .rounded-icon:hover {
      color: #ffffff;
      text-shadow: 0 0 10px #99eb99;
    }
  
    .animated-bar {
      background: linear-gradient(270deg, #00b300, #1b3b1b);
      background-size: 300% 300%;
      animation: darkGradientShift 6s ease-in-out infinite;
    }
  
    .Icon-arrow_up {
      background: linear-gradient(135deg, #1b2b1b, #1b3b1b);
      border-radius: 50%;
      padding: 10px;
      color: #33cc33;
      text-shadow: 0 0 6px #00b300;
      transition: 0.3s;
    }
  
    .Icon-arrow_up:hover {
      color: #ffffff;
      text-shadow: 0 0 10px #99eb99;
    }
  `;
  document.head.appendChild(greenStyle);
  
  // Animated glowing gradient text for _main ._label
  (function () {
    const el = document.querySelector('._main ._label');
    if (!el) return;
  
    el.style.backgroundImage = 'linear-gradient(90deg, white, #00b300, white)';
    el.style.backgroundSize = '300% auto';
    el.style.color = 'transparent';
    el.style.backgroundClip = 'text';
    el.style.webkitBackgroundClip = 'text';
    el.style.fontWeight = 'bold';
    el.style.animation = 'shine 2s linear infinite, glow 1.5s ease-in-out infinite alternate';
    el.style.textShadow = `
      0 0 4px #54d54f,
      0 0 8px #2dc02d,
      0 0 16px #00b300,
      0 0 24px white
    `;
  })();
  
  // Apply to common components
  const greenSelectors = [
    '._top', '._bottom',
    '.main-v2f8c4', '.main-zf0xiu', '.main-1tz8zqw',
    '.main-hp9qcx', '.main-x9v4u5', '.in_container',
    '._clickable', '.Icon-arrow_up', '.fa-play'
  ];
  
  function applyGreenTheme(el) {
    if (el.classList.contains('_top') || el.classList.contains('_bottom')) {
      el.classList.add('animated-bar');
      el.style.color = '#99e699';
      el.querySelectorAll('*').forEach(child => {
        child.style.color = '#99e699';
        child.style.textShadow = '0 0 6px #28ca28';
      });
      return;
    }
  
    el.style.background = 'linear-gradient(135deg, #1b2b1b, #1b3b1b)';
    el.style.color = '#99e699';
    el.style.borderRadius = '1rem';
    el.style.textShadow = '0 0 6px #00b300';
  
    if (el.classList.contains('Icon-arrow_up') || el.classList.contains('fa-play')) {
      el.classList.add('rounded-icon');
    }
  
    el.querySelectorAll('*').forEach(child => {
      child.style.color = '#99e699';
      child.style.textShadow = '0 0 6px #00b300';
    });
  }
  
  document.querySelectorAll(greenSelectors.join(',')).forEach(applyGreenTheme);
  
  const greenObserver = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (greenSelectors.some(sel => node.matches(sel))) {
            applyGreenTheme(node);
          }
          node.querySelectorAll(greenSelectors.join(',')).forEach(applyGreenTheme);
        }
      }
    }
  });
  greenObserver.observe(document.body, { childList: true, subtree: true });
  
  // _active animation
  const greenStyledElements = new WeakMap();
  setInterval(() => {
    document.querySelectorAll('._active').forEach(el => {
      if (!el.classList.contains('_active-gradient-animated')) {
        if (!greenStyledElements.has(el)) {
          greenStyledElements.set(el, {
            background: el.style.background,
            color: el.style.color,
            borderRadius: el.style.borderRadius,
          });
        }
        el.classList.add('_active-gradient-animated');
      }
    });
  }, 300);
  
// 🟢 Hero Shine Effect – Green Theme
function applyGreenShiny(el) {
  if (!el.classList.contains('green-shiny')) {
    el.classList.add('green-shiny');
  }
}

const greenTarget = document.querySelector('.main-y3ei6l');
if (greenTarget) applyGreenShiny(greenTarget);

const greenWatcher = new MutationObserver(() => {
  const el = document.querySelector('.main-y3ei6l');
  if (el) {
    applyGreenShiny(el);
    greenWatcher.disconnect();
  }
});
greenWatcher.observe(document.body, { childList: true, subtree: true });




  
  // _today styling
  function styleTodayElement(el) {
    el.style.background = 'linear-gradient(135deg, #00d700, #00a500)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #00cc00';
    el.style.fontWeight = 'bold';
  }
  document.querySelectorAll('._today').forEach(styleTodayElement);
  const observerToday = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_today')) {
            styleTodayElement(node);
          }
          node.querySelectorAll('._today').forEach(styleTodayElement);
        }
      }
    }
  });
  observerToday.observe(document.body, { childList: true, subtree: true });
  
  // Apply to existing elements
  document.querySelectorAll('._fore').forEach(styleForeElement);
  
  // Observe and style new elements dynamically
  const observerFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === 1) {
          if (node.classList.contains('_fore')) styleForeElement(node);
          node.querySelectorAll('._fore').forEach(styleForeElement);
        }
      }
    }
  });
  observerFore.observe(document.body, { childList: true, subtree: true });
  
  // GREEN STYLING FOR _day AND _note
  function styleGreenDay(el) {
    el.style.background = 'linear-gradient(135deg, #66dd66, #00aa00)';
    el.style.color = '#000';
    el.style.borderRadius = '1rem';
    el.style.boxShadow = '0 0 8px #33cc33';
    el.style.fontWeight = 'bold';
  }
  function styleGreenNote(el) {
    el.style.background = 'linear-gradient(135deg, #cdffcd, #66ff66)';
    el.style.color = '#1b2b1b';
    el.style.borderRadius = '0.75rem';
    el.style.padding = '8px';
    el.style.boxShadow = '0 0 10px #4fd54f';
  }
  document.querySelectorAll('._day').forEach(styleGreenDay);
  document.querySelectorAll('._note').forEach(styleGreenNote);
  const observerGreen = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('_day')) styleGreenDay(node);
        if (node.classList.contains('_note')) styleGreenNote(node);
        node.querySelectorAll('._day').forEach(styleGreenDay);
        node.querySelectorAll('._note').forEach(styleGreenNote);
      }
    }
  });
  observerGreen.observe(document.body, { childList: true, subtree: true });
  
  // Green calendar icon
  function styleGreenCalendar(el) {
    el.style.color = '#33cc33';
    el.style.textShadow = '0 0 6px #00b300';
    el.style.background = 'none';
  }
  document.querySelectorAll('.fa-calendar-alt').forEach(styleGreenCalendar);
  const calendarObserverGreen = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList.contains('fa-calendar-alt')) {
          styleGreenCalendar(node);
        }
        node.querySelectorAll('.fa-calendar-alt').forEach(styleGreenCalendar);
      }
    }
  });
  calendarObserverGreen.observe(document.body, { childList: true, subtree: true });
  
  // Green style for .fa-calendar-star
  const style = document.createElement('style');
  style.textContent = `
    .fa-calendar-star,
    .fa-calendar-star::before {
      color: #00D700 !important;
    }
  `;
  document.head.appendChild(style);
  const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === 1) {
          if (node.classList?.contains('fa-calendar-star')) {
            node.style.color = '#00D700';
          } else {
            node.querySelectorAll?.('.fa-calendar-star')?.forEach(el => {
              el.style.color = '#00D700';
            });
          }
        }
      });
    });
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Only change text color of _dots elements to green
  function styleGreenDots(el) {
    el.style.color = '#33cc33';
    el.style.textShadow = '0 0 4px #00b300';
  }
  
  // Apply to existing ._dots elements
  document.querySelectorAll('._dots').forEach(styleGreenDots);
  
  // Observe for future ._dots elements
  const observerDots = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('_dots')) styleGreenDots(node);
        node.querySelectorAll('._dots').forEach(styleGreenDots);
      }
    }
  });
  observerDots.observe(document.body, { childList: true, subtree: true });
  
  document.querySelectorAll('._fore').forEach(el => {
    el.style.setProperty('background', 'linear-gradient(135deg, #007f00, #005400)', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #007f00', 'important');
  
    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  });
  
  // Combined Green Theme Enhancements
  
  // Font Awesome Icons to Green
  function styleAllFontAwesome(el) {
    el.style.setProperty('color', '#33cc33', 'important');
    el.style.setProperty('textShadow', '0 0 6px #00b300', 'important');
  }
  document.querySelectorAll('.fa, .fas, .far, .fal, .fab').forEach(styleAllFontAwesome);
  const observerFA = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.toString().match(/\bfa[bsrl]?\b/)) {
          styleAllFontAwesome(node);
        }
        node.querySelectorAll?.('.fa, .fas, .far, .fal, .fab')?.forEach(styleAllFontAwesome);
      }
    }
  });
  observerFA.observe(document.body, { childList: true, subtree: true });
  
  // Green Background for .main-1k6w26b
  const styleMain = document.createElement('style');
  styleMain.innerHTML = `
    .main-1k6w26b {
      background: linear-gradient(135deg, #1b3b1b, #1b2b1b) !important;
      color: #33cc33 !important;
      border: 2px solid #4e6b00 !important;
      border-radius: 0.75rem !important;
      box-shadow: 0 0 10px #00b300 !important;
      padding: 12px !important;
      transition: border 0.3s ease, box-shadow 0.3s ease;
    }
    .main-1k6w26b:hover {
      border: 2px solid #33cc33 !important;
      box-shadow: 0 0 14px #33cc33 !important;
    }
  `;
  document.head.appendChild(styleMain);
  function styleGreenMainBlock(el) {
    el.classList.add('main-1k6w26b');
  }
  document.querySelectorAll('.main-1k6w26b').forEach(styleGreenMainBlock);
  const observerGreenMainBlock = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('main-1k6w26b')) {
          styleGreenMainBlock(node);
        }
        node.querySelectorAll?.('.main-1k6w26b')?.forEach(styleGreenMainBlock);
      }
    }
  });
  observerGreenMainBlock.observe(document.body, { childList: true, subtree: true });
  
  // Green Border Shades for .main-uv8k3y
  const styleUv = document.createElement('style');
  styleUv.innerHTML = `
    .main-uv8k3y {
      border: 2px solid #608000 !important; /* darker green base */
      transition: border 0.3s ease, box-shadow 0.3s ease;
      border-radius: 0.75rem !important;
    }
    .main-uv8k3y:hover {
      border: 2px solid #33cc33 !important; /* bright green */
      box-shadow: 0 0 10px #33cc33 !important;
    }
  `;
  document.head.appendChild(styleUv);
  
  // Apply to existing elements
  document.querySelectorAll('.main-uv8k3y').forEach(el => {
    el.classList.add('main-uv8k3y');
  });
  
  // Observe and apply to new elements
  const observerUv = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList?.contains('main-uv8k3y')) {
          node.classList.add('main-uv8k3y');
        }
  
        node.querySelectorAll?.('.main-uv8k3y')?.forEach(el => {
          el.classList.add('main-uv8k3y');
        });
      }
    }
  });
  observerUv.observe(document.body, { childList: true, subtree: true });
  
  // Make all elements inside ._fore have transparent background
  function applyForeInnerStyle(el) {
    const darkGreen = '#1b3b1b';
  
    el.querySelectorAll('*').forEach(child => {
      const isFontAwesome =
        [...child.classList].some(cls =>
          cls.startsWith('fa') || ['fas', 'far', 'fal', 'fab'].includes(cls)
        );
  
      if (isFontAwesome) {
        child.style.setProperty('background', darkGreen, 'important');
        child.style.setProperty('color', '#33cc33', 'important');
        child.style.setProperty('borderRadius', '0.5rem', 'important');
        child.style.setProperty('padding', '6px', 'important');
        child.style.setProperty('textShadow', '0 0 6px #00b300', 'important');
      } else {
        child.style.setProperty('background', 'transparent', 'important');
      }
    });
  }
  
  // Apply to all existing _fore elements
  document.querySelectorAll('._fore').forEach(applyForeInnerStyle);
  
  // Observe future _fore elements and their children
  const observerForeInner = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('._fore')) applyForeInnerStyle(node);
  
        node.querySelectorAll?.('._fore')?.forEach(applyForeInnerStyle);
      }
    }
  });
  observerForeInner.observe(document.body, { childList: true, subtree: true });
  
  // Style ._fore with dark green and children transparent
  function styleForeElement(el) {
    const darkGreen = '#0a3a0a';
  
    el.style.setProperty('background', darkGreen, 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('box-shadow', `0 0 8px ${darkGreen}`, 'important');
  
    el.querySelectorAll('*').forEach(child => {
      child.style.setProperty('background', 'transparent', 'important');
    });
  }
  
  // Apply to existing ._fore
  document.querySelectorAll('._fore').forEach(styleForeElement);
  
  // Observe and apply to new ._fore elements
  const observerStrictFore = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList?.contains('._fore')) {
          styleForeElement(node);
        }
  
        node.querySelectorAll?.('._fore')?.forEach(styleForeElement);
      }
    }
  });
  observerStrictFore.observe(document.body, { childList: true, subtree: true });
  
  // Dark Green Style for .container-children
  function styleDarkGreenContainer(el) {
    el.style.setProperty('background', 'linear-gradient(135deg, #0a3a0a, #3cb371)', 'important');
    el.style.setProperty('color', '#f0fff0', 'important');
    el.style.setProperty('border-radius', '1rem', 'important');
    el.style.setProperty('padding', '12px', 'important');
    el.style.setProperty('box-shadow', '0 0 10px #086508', 'important');
  }
  
  // Apply to existing elements
  document.querySelectorAll('.container-children').forEach(styleDarkGreenContainer);
  
  // Observe and apply to future elements
  const observerContainerChildren = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.classList?.contains('container-children')) {
          styleDarkGreenContainer(node);
        }
        node.querySelectorAll?.('.container-children')?.forEach(styleDarkGreenContainer);
      }
    }
  });
  observerContainerChildren.observe(document.body, { childList: true, subtree: true });
  
  // Style function for .widget-title
  function styleWidgetTitle(el) {
    el.style.setProperty('background', '#1b3b1b', 'important'); // dark green bg
    el.style.setProperty('color', '#33cc33', 'important');      // bright green text
    el.style.setProperty('text-shadow', '0 0 6px #00b300', 'important');
    el.style.setProperty('padding', '6px 12px', 'important');
    el.style.setProperty('border-radius', '0.5rem', 'important');
  }
  
  // Apply to existing .widget-title elements
  document.querySelectorAll('.widget-title').forEach(styleWidgetTitle);
  
  // Observe future .widget-title elements
  const observerWidgetTitle = new MutationObserver(mutations => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== 1) continue;
  
        if (node.classList.contains('widget-title')) {
          styleWidgetTitle(node);
        }
  
        node.querySelectorAll?.('.widget-title')?.forEach(styleWidgetTitle);
      }
    }
  });
  observerWidgetTitle.observe(document.body, { childList: true, subtree: true });
  
  // Use a unique observer name to avoid conflicts
  const observer_css1h088zk_green = new MutationObserver(() => {
    document.querySelectorAll('.css-1h088zk').forEach(el => {
      el.style.cssText += `
        background-color: #2e8b57 !important;  /* Green background */
        color: #f0fff0 !important;             /* Light text for contrast */
        border-radius: 8px !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 0 10px #1b5e20 !important; /* Subtle green glow */
      `;
      console.log('Green style applied:', el);
    });
  });
  
  // Apply immediately in case the element already exists
  document.querySelectorAll('.css-1h088zk').forEach(el => {
    el.style.cssText += `
      background-color: #2e8b57 !important;
      color: #f0fff0 !important;
      border-radius: 8px !important;
      transition: all 0.3s ease !important;
      box-shadow: 0 0 10px #1b5e20 !important;
    `;
    console.log('Green style applied:', el);
  });
  
  // Observe for future elements
  observer_css1h088zk_green.observe(document.body, {
    childList: true,
    subtree: true,
  });
  
  // Green colors
  const mainGreen = '#2e8b57';     // For the main element
  const beforeGreen = '#64d264';   // Slightly lighter green for ::before
  
  // Add style for ::before only (color only, no position/layout changes)
  const pseudoStyle = document.createElement('style');
  pseudoStyle.textContent = `
    ._unit_name::before {
      background-color: ${beforeGreen} !important;
    }
  `;
  document.head.appendChild(pseudoStyle);
  
  // Function to style all _unit_name elements
  const styleUnitNameGreen = () => {
    document.querySelectorAll('._unit_name').forEach(el => {
      el.style.backgroundColor = mainGreen;
      el.style.color = '#f0fff0';
      el.style.borderRadius = '6px';
      el.style.padding = '4px';
      el.style.transition = 'all 0.3s ease';
    });
  };
  
  // Apply to existing elements
  styleUnitNameGreen();
  
  // Watch for new _unit_name elements
  const observer_unit_name_green = new MutationObserver(() => {
    styleUnitNameGreen();
  });
  observer_unit_name_green.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Green styling (color only)
  const applyGreenToMain = () => {
    document.querySelectorAll('.main-18ys6ck').forEach(el => {
      el.style.backgroundColor = '#2e8b57'; // Moderate green
      el.style.color = '#f0fff0';           // Light text for contrast
      el.style.transition = 'all 0.3s ease';
    });
  };
  
  // Run initially
  applyGreenToMain();
  
  // Watch for new elements
  const observer_main_green = new MutationObserver(() => {
    applyGreenToMain();
  });
  observer_main_green.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Hover border color (green)
  const hoverBorderGreen = '#2e8b57'; // Green on hover
  
  // Inject CSS for both classes
  const hoverStyle = document.createElement('style');
  hoverStyle.textContent = `
    .padding:hover,
    .main-5u5jqx:hover {
      border: 2px solid ${hoverBorderGreen} !important;
      transition: border-color 0.3s ease !important;
    }
  `;
  document.head.appendChild(hoverStyle);
  
  // Function to ensure classes are applied (even dynamically)
  const applyHoverClasses = () => {
    document.querySelectorAll('.padding, .main-5u5jqx').forEach(el => {
      // Just ensures the class is not stripped; styling is handled via CSS
      el.classList.add(...el.classList);
    });
  };
  applyHoverClasses();
  
  // Observe DOM for new elements
  const observer_hover_green = new MutationObserver(() => {
    applyHoverClasses();
  });
  observer_hover_green.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Define CSS with gradient and animation
  const styleXzur6n = document.createElement('style');
  styleXzur6n.textContent = `
    @keyframes greenGradientMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }
  
    .css-xzur6n {
      background: linear-gradient(270deg, #2e8b57, #64d264, #00a000);
      background-size: 600% 600%;
      animation: greenGradientMove 6s ease infinite;
      color: #f0fff0 !important;
      transition: all 0.3s ease;
      border-radius: 6px;
    }
  `;
  document.head.appendChild(styleXzur6n);
  
  // Apply class styles if already present
  const applyGreenGradient = () => {
    document.querySelectorAll('.css-xzur6n').forEach(el => {
      el.classList.add('css-xzur6n'); // No-op but ensures consistency
    });
  };
  
  applyGreenGradient(); // Immediate
  
  // Observer to handle dynamically added elements
  const observer_xzur6n = new MutationObserver(() => {
    applyGreenGradient();
  });
  observer_xzur6n.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  console.log("🟢 Green theme script injected");