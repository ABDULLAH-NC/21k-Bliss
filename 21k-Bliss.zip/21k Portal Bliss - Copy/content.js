console.log('[content.js] Loaded on page.');

const injectTheme = (name) => {
  // Remove all previously injected theme scripts
  const existing = document.querySelectorAll('script[id^="theme-script"]');
  existing.forEach(el => el.remove());

  if (name === 'none') {
    document.documentElement.style.backgroundColor = '';
    return;
  }

  // ⏱ Wait 5 seconds after full load
  setTimeout(() => {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL(`${name}-theme.js`);
    script.id = `theme-script-${name}`;
    document.documentElement.appendChild(script);

    document.documentElement.style.backgroundColor = 'rgb(45, 51, 59)';
    console.log(`→ Injected ${name}-theme.js after full load and 5s delay`);
  }, 100); // ← 5 seconds
};

// 🧠 Wait for full page load before injecting
window.addEventListener('load', () => {
  console.log('✅ Page fully loaded');
  chrome.storage.sync.get('selectedTheme', (data) => {
    const theme = data.selectedTheme || 'none';
    console.log(`• Stored theme: ${theme}`);
    injectTheme(theme);
  });
});

// 📩 Handle messages from popup (theme change)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.theme) {
    chrome.storage.sync.set({ selectedTheme: request.theme }, () => {
      setTimeout(() => {
        location.reload(); // Refresh to clean and apply
      }, 200);
    });
  }
});
